#!/bin/bash
#
# contoh untuk menjalanjan bot dari script bash
#

# cd ke folder script ini
DIR="$( cd "$( dirname "$0" )" && pwd )"
cd "$DIR"

# jalankan bot
php wasapbot.php
