/*
===========================================================================
 EXCLUSIVE ON themeforest.net
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 Template Name   : Abroad - Personal Portfolio Template
 Author          : bootWeb
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 Copyright (c) 2017 - bootWeb - https://themeforest.net/user/bootweb
===========================================================================
*/

/*================================================
            Table of contents  
==================================================
 
1. Scroll to top

====================================================
            End table content 
===================================================*/

$(function () {
 "use strict";

 var $window = $(window),
 $body = $('body');

 jQuery(document).ready(function($){

    	//Scroll-to-up
    	$('#scroll-up').hide();
    	$window.on("scroll", function () {
    		if ($window.scrollTop() > 300) {
    			$('#scroll-up').fadeIn();
    		} else {
    			$('#scroll-up').fadeOut();
    		}
    	});
    	$('#scroll-up').on("click", function () {
    		$("html, body").animate({
    			scrollTop: 0
    		}, 1000);
    		return false;
    	});

    }(jQuery));
});