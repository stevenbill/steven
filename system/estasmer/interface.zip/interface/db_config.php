<?php
$host= "localhost";
$username= "ahmedyosry";
$password = "usbwusbw";
$db_name = "mapcompany";
$db = new mysqli($host,$username,$password,$db_name);
if($db->connect_error)
{
	die("connection failed:". $db->connect_error);
	
}
?>