<?php

session_start();

 $seg=$_SESSION['logindata'];


/*
// set timeout period in seconds (600 = 10 minutes)
$inactive = 300;
// check to see if $_SESSION['timeout'] is set
if(isset($_SESSION['timeout']) ) {
    $session_life = time() - $_SESSION['timeout'];
    if($session_life > $inactive)
        { session_destroy(); header("Location: destroy.php"); }
}
$_SESSION['timeout'] = time();



if(!isset($_SESSION['logindata']))
    {
        header('Location: destroy.php');
    }



if(!isset($_SERVER['HTTP_REFERER'])){
// redirect them to your desired location
header('location: destroy.php');
exit;


}*/


?>









<!DOCTYPE html>
<html >
<head>
    <style>
    .btn-bs-file{
    position:relative;
}
.btn-bs-file input[type="file"]{
    position: absolute;
    top: -9999999;
    filter: alpha(opacity=0);
    opacity: 0;
    width:0;
    height:0;
    outline: none;
    cursor: inherit;
}
    
    
    </style>
  <meta charset="UTF-8">
  <title>Maptec syestem </title>
    <script src="https://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>
    
 
    
    
    
   


  
  <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css'>
<link rel='stylesheet prefetch' href='http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.0/css/bootstrapValidator.min.css'>
      <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/css/bootstrap-datetimepicker.min.css'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>
  <div class="container">

    <form class="well form-horizontal" action="fax.php" method="post"  id="contact_form">
<fieldset>

<!-- Form Name -->
<legend>Company Fax</legend>
    
    <?php
    echo "welcom ***" .$seg."***";
    ?>

<!-- Text input-->

  <?php
include('db_config.php');
$sql= "SELECT * FROM `company`";
$query = $db->query($sql);
$data = $query->fetch_assoc();

?>
<div class="form-group"> 
  <label class="col-md-4 control-label">Company name</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
         <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>

<select class="form-control selectpicker"  name="CompanyName" id="country"  class="dropdown" onchange="change_country();" required>
<option value="">Select Company</option> 
<?php while($row = $query->fetch_assoc()) { ?>
  <option  value="<?php echo $row['CompanyName']; ?>"><?php echo $row['CompanyName']; ?> </option>
<?php } ?>
</select>
 </div>
</div>
</div>
    
    
    



<div class="form-group"> 
  <label class="col-md-4 control-label">Phone Number </label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
         <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
<select class="form-control selectpicker" name="PhoneNumber" id="state" class="dropdown" required>
<option value="">Select State</option>

</select>
 </div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script>
function change_country()
{
  var country = $("#country").val();
  
     $.ajax({
    type: "POST",
    url: "state.php",
    data: "country="+country,
    cache: false,
    success: function(response)
      {
          //alert(response);return false;
        $("#state").html(response);
      }
      });
    
    
    
    var country2 = $("#country2").val();
  
     $.ajax({
    type: "POST",
    url: "state2.php",
    data: "country="+country,
    cache: false,
    success: function(response)
      {
          //alert(response);return false;
        $("#state2").html(response);
      }
      });
  
    
    
    
    
    
    
    
    
  
}

    
  </script>
    
 
<!-- Text input-->


      
    
    
    
    
    
    
    

 
        <div class="form-group"> 
  <label class="col-md-4 control-label">Fax Result</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="FaxResult"  class="form-control selectpicker" required>
      <option></option>
      <option value="Sent">Sent</option>
      <option value="No Answer">No Answer</option>
        <option value="Reject">Reject</option>

    </select>
  </div>
</div>
</div>
    
      <div class="form-group"> 
  <label class="col-md-4 control-label">Fax Dep</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="FaxDep"  class="form-control selectpicker" required>
      <option></option>
      <option value="GIS">GIS</option>
      <option value="Survey">Survey</option>
        <option value="Construction">Construction</option>

    </select>
  </div>
</div>
</div>
    
    
    
    
     <div class="form-group"> 
  <label class="col-md-4 control-label">Fax Brand</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="FaxBrand"  class="form-control selectpicker" required>
      <option ></option>
      <option value="Maptec">Maptec</option>
      <option value="Estasmer">Estasmer</option>
        <option value="Construction">Construction</option>

    </select>
  </div>
</div>
</div>

    
    
       <div align="center">


        <hr/>

    
    
    
    
    
    
<!--
<div class="form-group"> 
  <label class="col-md-4 control-label">Fax root </label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
         <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
<select class="form-control selectpicker" name="state" id="state1" class="dropdown">
<option value="">Select State</option>

</select>
 </div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script>
function change_country2()
{
  var country = $("#country").val();
  
     $.ajax({
    type: "POST",
    url: "state2.php",
    data: "country1="+country,
    cache: false,
    success: function(response)
      {
          //alert(response);return false;
        $("#state1").html(response);
      }
      });
  
}
</script>-->

    
    
    
   

    
    
   <!--
<div class="form-group"> 
  <label class="col-md-4 control-label">Refrence</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="Refrence" class="form-control selectpicker" >
      <option value=" " ></option>
      <option value="Alabama">Alabama</option>
      <option value="Alaska">Alaska</option>
      <option value="Arizona" >Arizona</option>
      <option value="Arkansas" >Arkansas</option>
   
    </select>
  </div>
</div>
</div>

<!-- Text input

<div class="form-group">
  <label class="col-md-4 control-label">Zip Code</label>  
    <div class="col-md-4 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
  <input name="zip" placeholder="Zip Code" class="form-control"  type="text">
    </div>
</div>
</div>

<!-- Text input-->


<!-- radio checks
 <div class="form-group">
                        <label class="col-md-4 control-label">Do you have hosting?</label>
                        <div class="col-md-4">
                            <div class="radio">
                                <label>
                                    <input type="radio" name="hosting" value="yes" /> Yes
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="hosting" value="no" /> No
                                </label>
                            </div>
                        </div>
                    </div>

<!-- Text area -->
            <?php
mysql_connect("localhost", "ahmedyosry","usbwusbw") or die(mysql_error());
mysql_select_db("mapcompany")  or die(mysql_error());

$query = "SELECT * FROM faxroot ";
$result = mysql_query($query) or die(mysql_error()."[".$query."]");
?>
   
<div class="form-group"> 
  <label class="col-md-4 control-label">Fax list</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select  required class="form-control selectpicker" name="Faxroot">
<?php 
while ($row = mysql_fetch_array($result))
{
 
    echo "<option   value='".$row['fax']."'>'".$row['fax']."'</option>";

     
   
}
   
        
   
?> 

 
</select>
          </div>
</div>
</div>
    
    
    
    
    
    
    
  
<div class="form-group">
  <label class="col-md-4 control-label">Notes</label>
    <div class="col-md-6 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-pencil"></i></span>
        	<textarea class="form-control" name="Notes" placeholder="Project Description" ></textarea>
  </div>
  </div>
</div>
           
           
           
           
     
           
           
           

    

<!-- Success message -->
<br> <br> 

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4">
    <input type="submit" class="btn btn-warning"  value="save" name="send" >
  </div>
    <br>
    
  <br> <br> 

    


</div>
          

</fieldset>
       
</form>
      
    <?php
        
        if($_POST['show']){
            
            
           header('location: faxshow.php'); 
            
        }
        
        
$localhost="localhost";
$user_db="ahmedyosry";
$pass_db="usbwusbw";
$db="mapcompany";


$connect=mysql_connect("$localhost","$user_db","$pass_db");
mysql_set_charset('utf8');
if ($connect) {

mysql_select_db($db) or die("db selction error ");
    
	 session_start();
	$seg= $_SESSION['logindata'];

   







}else{
	
	mysql_error();
}
        
   




$CompanyName =$_POST['CompanyName'];
 $PhoneNumber=$_POST['PhoneNumber'];
  $FaxResult= $_POST['FaxResult'];
 $FaxDep= $_POST['FaxDep'];
   
      $FaxBrand= $_POST['FaxBrand'];
      $Notes = $_POST['Notes'];
      $Faxroot = $_POST['Faxroot'];
    
      $date=@date("Y/m/d h:i:sa") ;
       
        
        $mobile1; // This is integer
/*$s = $mobile1."";*/ // Now $s is string. 
echo $mobile1[2]; // Now $s is array. 
        if($mobile1[2]==11){
            
        }else{
            
        }

$sql="insert into  fax (CompanyName,PhoneNumber,FaxResult,FaxDep,FaxBrand,Notes,date,Faxroot,seg) values('$CompanyName','$PhoneNumber','$FaxResult','$FaxDep','$FaxBrand','$Notes','$date','$Faxroot','$seg')";

if (@ $_POST['send']) {


  mysql_query($sql); 
    echo $Faxroot;
echo"<a href='imgdow/$Faxroot' target='_blank'>Fax download!</a>";
    
    echo "<script> alert('Thank you for your insert ?  ') </script>";

echo"<div class='alert alert-success' role='alert' id='success_message'>Success <i class='glyphicon glyphicon-thumbs-up'></i> Thanks for send data.</div>";




}





























      ?>
</div>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>
     <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/3.1.3/js/bootstrap-datetimepicker.min.js'></script>

    <script src="js1/index.js"></script>


    <script src="js/index.js"></script>
    

</body>
</html>
