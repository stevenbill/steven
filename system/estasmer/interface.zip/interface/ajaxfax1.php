

<?php
/*if(!isset($_SERVER['HTTP_REFERER'])){
// redirect them to your desired location
header('location: destroy.php');
exit;

    

}*/


?>



<?php

session_start();





/*
// set timeout period in seconds (600 = 10 minutes)
$inactive = 300;
// check to see if $_SESSION['timeout'] is set
if(isset($_SESSION['timeout']) ) {
    $session_life = time() - $_SESSION['timeout'];
    if($session_life > $inactive)
        { session_destroy(); header("Location: destroy.php"); }
}
$_SESSION['timeout'] = time();



if(!isset($_SESSION['logindata']))
    {
        header('Location: destroy.php');
    }*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Company data</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">

    <link href="map//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href="map/vendors/form-helpers/css/bootstrap-formhelpers.min.css" rel="stylesheet">
    <link href="map/vendors/select/bootstrap-select.min.css" rel="stylesheet">
    <link href="map/vendors/tags/css/bootstrap-tags.css" rel="stylesheet">

    <link href="map/css/forms.css" rel="stylesheet">
    

    
          <script>
            function send(){
                var user=document.getElementById('user').value;
                  var pass=document.getElementById('pass').value;
                
                 var fax2=document.getElementById('fax2').value;
                 var fax3=document.getElementById('fax3').value;
                var mobile1=document.getElementById('mobile1').value;
                var mobile2=document.getElementById('mobile2').value;
                var mobile3=document.getElementById('mobile3').value;
                var EMail1=document.getElementById('EMail1').value; 
                var EMail2=document.getElementById('EMail2').value; 
                var EMail3=document.getElementById('EMail3').value;
                var oldURL=document.getElementById('oldURL').value;
                var Url=document.getElementById('Url').value;
                var Address=document.getElementById('Address').value;
                var Phone1=document.getElementById('Phone1').value;
                var Phone2=document.getElementById('Phone2').value;
                var Phone3=document.getElementById('Phone3').value;
                var Type=document.getElementById('Type').value;
                 var Brand=document.getElementById('Brand').value;
                var Dep=document.getElementById('Dep').value; 
                 var Ar_Name=document.getElementById('Ar_Name').value;
                var En_Name=document.getElementById('En_Name').value; 
                var Field_of_Work=document.getElementById('Field_of_Work').value; 
                
$("#test").load("ajaxfax2.php",{user:user,pass:pass,fax2:fax2,fax3:fax3,mobile1:mobile1,mobile2:mobile2,mobile3:mobile3,EMail1:EMail1,EMail2:EMail2,EMail3:EMail3,oldURL:oldURL,Url:Url,Address:Address,Phone1:Phone1,Phone2:Phone2,Phone3:Phone3,Type:Type,Brand:Brand,Dep:Dep,Ar_Name:Ar_Name,En_Name:En_Name,Field_of_Work:Field_of_Work});
               
                
            }
        </script>
  

</head>
<body>
    
          <div id="test">

    
        </div>
   
    
     	<div class="header">
	     <div class="container">
	        <div class="row">
	           <div class="col-md-5">
	              <!-- Logo -->
	              <div class="logo">
	                         <h1><a href="add.php">Edit call and order  </a></h1>
	              </div>
	           </div>
	           <div class="col-md-5">
	              <div class="row">
	                <div class="col-lg-12">
	               
	                </div>
	              </div>
	           </div>
	           <div class="col-md-2">
	              <div class="navbar navbar-inverse" role="banner">
	                  <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
	                    <ul class="nav navbar-nav">
	                      <li class="dropdown">
	                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <?php echo "user/".$seg= $_SESSION['logindata'];    ?>          <b class="caret"></b></a>
	                        <ul class="dropdown-menu animated fadeInUp">

	                          
	                       <li><a href="destroy.php">Logout</a></li>
	                        </ul>
	                      </li>
	                    </ul>
	                  </nav>
	              </div>
	           </div>
	        </div>
	     </div>
	</div>
    
    
    
    <?php
    session_start();

 $seg=$_SESSION['logindata'];
    
    
    $id=$_GET['up'];
    
    $localhost="localhost";
$user_db="ahmedyosry";
$pass_db="usbwusbw";
$db="mapcompany";

$connect=mysql_connect("$localhost","$user_db","$pass_db");
mysql_set_charset('utf8');
if ($connect) {

mysql_select_db($db) or die("db selction error ");

}else{
	
	mysql_error();
}
    
$sql2="SELECT * FROM users where user='$seg' " ;
$q2=mysql_query($sql2) ;
    
    while($row1=mysql_fetch_array($q2)){
         $Type1 = $row1['Type'];
         $Brand1 = $row1['Brand']; 
          $Dep1 = $row1['Dep'];
         $Ar_Name1 = $row1['Ar_Name'];
         $En_Name1 = $row1['En_Name'];
         $Field_of_Work1 = $row1['Field_of_Work']; 
         $fax11 = $row1['fax1'];
         $fax12 = $row1['fax2'];
         $fax13 = $row1['fax3'];
         $Phone11 = $row1['Phone1'];
         $Phone12 = $row1['Phone2'];
         $Phone13 = $row1['Phone3'];
         $mobile11 = $row1['mobile1'];
         $mobile12 = $row1['mobile2'];
         $mobile13 = $row1['mobile3'];
         $EMail11 = $row1['EMail1'];
         $EMail12 = $row1['EMail2'];
         $EMail13 = $row1['EMail3'];
         $oldURL1 = $row1['oldURL'];
         $Url1 = $row1['Url']; 
         $Address1 = $row1['Address']; 
        
        
    }
    
$sql="SELECT * FROM company where id='$id' " ;
$q=mysql_query($sql) ;
    
    while($row=mysql_fetch_array($q)){
    $fax1 = $row['fax1'];
         $fax2 = $row['fax2'];
         $fax3 = $row['fax3'];
        $mobile1= $row['mobile1'];
        $mobile2= $row['mobile2'];
        $mobile3= $row['mobile3'];
        $EMail1= $row['EMail1'];
        $EMail2= $row['EMail2'];
        $EMail3= $row['EMail3'];
        $oldURL = $row['oldURL']; 
        $Url = $row['Url'];
        $Address= $row['Address'];
        $Phone1 = $row['Phone1'];
        $Phone2 = $row['Phone2'];
        $Phone3 = $row['Phone3'];
        $Ar_Name = $row['Ar_Name'];
        $En_Name= $row['En_Name'];
        $Field_of_Work = $row['Field_of_Work'];
        $Type = $row['Type'];
        $Brand = $row['Brand'];
        $Dep = $row['Dep'];
        $Field_of_Work = $row['Field_of_Work'];
       
       
    
    
    
   
   
   
    
}
    
      
    

    
    
    
    
    
  ?>
   <?php
include('db_config.php');
$sql= "SELECT * FROM `company`";
$query = $db->query($sql);
$data = $query->fetch_assoc();

?>
<div class='well'>
<div class="form-group"> 
  <label class='col-xs-5 control-label'><strong>1.</strong>&nbsp;company name</label>
   <div class='col-xs-2'>
    
         

<select class="form-control selectpicker"  name="counntry" id="country" class="dropdown" onchange="change_country();">
<option value="">Select Company</option>
<?php while($row = $query->fetch_assoc()) { ?>
  <option  value="<?php echo $row['CompanyName']; ?>"><?php echo $row['CompanyName']; ?> </option>
<?php } ?>
</select>
 </div>
</div>
</div>
    
<?php
   
    
       
     echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>7.</strong>&nbsp;Name</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='user' type='text' value='$name' class='form-control' $name >"; 
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
     echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>3.</strong>&nbsp;Postion</label>";
    echo"<div class='col-xs-2'>";
    
       echo "<select required  name='Dep' id='Dep' class='form-control' $Postion  >";
       echo"<option value='$Postion'>$Postion</option>"; 
           echo"<option value='Engineer'>Engineer</option>";
      echo"<option value='Market manager
'>Market manager
</option>";
        
      echo"<option value='Company owner
'>Company owner
</option>";
        echo"<option value='Technical Office
'>Technical Office
</option>";
        echo"<option value='Purchases
'>Purchases
</option>";
        echo"<option value='Marketing manager
'>Marketing manager
</option>";
        echo"<option value='Sales manager
'>Sales manager
</option>";
        echo"<option value='Company manager'>Company manager</option>";
          echo"<option value='CEO
'>CEO
</option>";
          echo"<option value='other
'>other
</option>";
     
    echo"</select>";
    echo"</div>";
echo"</div>";
echo"</div>";
    
     
    /******************************************************************/

     echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>3.</strong>&nbsp;State of Call</label>";
    echo"<div class='col-xs-2'>";
    
       echo "<select required  name='Dep' id='Dep' class='form-control' $StateofCall  >";
       echo"<option value='$StateofCall'>$StateofCall</option>"; 
   echo" <option>Valid</option>";
      echo"<option>Out of Service</option>";
      
         echo"<option>Un Reached Now</option>";
         echo"<option>No Answer</option>";
         echo"<option>Line Busy</option>";
         echo"<option>Invalid Number</option>";
         echo"<option>Wrong Number</option>";
         echo"<option>Not Reachable</option>";
     
     
    echo"</select>";
    echo"</div>";
echo"</div>";
echo"</div>";
    


    
    
    
    
    

mysql_connect("localhost", "ahmedyosry","usbwusbw") or die(mysql_error());
mysql_select_db("mapcompany")  or die(mysql_error());

$query = "SELECT * FROM users  ";
$result = mysql_query($query) or die(mysql_error()."[".$query."]");
?>
   
<div class='well'>
<div class="form-group"> 
  <label class='col-xs-5 control-label'><strong>1.</strong>&nbsp;Caller_Follow</label>
   <div class='col-xs-2'>
    <select   class="form-control selectpicker"  name="Caller_Follow"  >
<?php 
while ($row = mysql_fetch_array($result))
{

    echo "<option   value='".$row['user']."'>'".$row['user']."'</option>";
     
}
    
   
?> 

 
</select>
          </div>
</div>
</div>
    
    

    
<div class='well'>
<div class="form-group"> 
  <label class='col-xs-5 control-label'><strong>1.</strong>&nbsp;New Field Work</label>
   <div class='col-xs-2'>
    <select   name="NewFieldWork" class="form-control selectpicker"  >
      <option> </option>
      <option value="Mechanical">Mechanical</option>
      <option value="Electromechanical">Electromechanical</option>
        <option value="Advertising">Advertising</option>
        <option value="Marketing">Marketing</option>
        <option value="Electricity">Electricity</option>
        <option value="Planning">Planning</option>
        <option value="Chemicals">Chemicals</option>
        
        <option value="Consulting">Consulting</option>
        <option value="Supply">Supply</option>
        <option value="Import & Export">Import & Export</option>
        <option value="Security">Security</option>
        <option value="Tourism">Tourism</option>
  <option value="مقولات تكيفيه مركزيه">      مقولات تكيفيه مركزيه </option> 
        <option value="Real Estate">Real Estate</option>
        <option value="Fittings">Fittings</option>
        <option value="Rental">Rental</option>
        
        
        
        
    
     
    </select>
  </div>
</div>
</div> 
    
    
    
    
    
    
    
<?php
    
    
    

    
         echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Phone 01</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Phone1' class='form-control' $Phone1 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
       echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Phone 01</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Phone1' class='form-control' $Phone1 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
       echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Phone 01</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Phone2' class='form-control' $Phone2 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
       echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Mobile1</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Mobile1' class='form-control' $Mobile1 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
    echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Mobile2</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Mobile2' class='form-control' $Mobile2 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Mobile3</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Mobile3' class='form-control' $Mobile3 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
    
      echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Email1</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Email1' class='form-control' $Email1 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
      echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Email2</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Email2' class='form-control' $Email2 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
      echo"<div class='well'>";
echo"<div class='form-group'>";
    echo"<label class='col-xs-5 control-label'><strong>8.</strong>&nbsp;Email3</label>";
    echo"<div class='col-xs-2'>";
    
    echo"<input id='fax2' type='number' value='$Email3' class='form-control' $Email3 >";   
    
echo"</div>";
echo"</div>";
echo"</div>";
    
    
    
    
    
    
    /**********************************************************************************************************************/
       
    /************************************************************************************************/
   
   
    
    
echo"<input type='text' hidden='hidden' id='pass' placeholder='pass' value='$id'  >";
 
    ?>
    
    
    <center>

    

<input onclick="send()" type="button" name="send" value=" Update" class='btn btn-success'  >
<br>
<br>
    </center>
    
    </body>
</html>