<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magento\Bundle\Test\Block\Catalog\Product\View\Type\Option;

use Magento\Bundle\Test\Block\Catalog\Product\View\Type\Option;

/**
 * Class Dropdown
 * Bundle option drop-down type
 */
class Dropdown extends Option
{
    // Parent behavior
}
