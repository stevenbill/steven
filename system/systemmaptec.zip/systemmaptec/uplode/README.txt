A Pen created at CodePen.io. You can find this one at https://codepen.io/DavidJones/pen/xwvVZO.

 ### qrcode and image maker

- drag and drop upload image
- drag qrcode in canvas
- url to qrcode base64 and png
- resize qrcode and canvas
- thanks