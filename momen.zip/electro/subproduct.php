
<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://demo2.chethemes.com/electro/xmlrpc.php">

				<script type="text/javascript">document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script>
			<title>Notebook Black Spire V Nitro  VN7-591G &#8211; Electro</title>
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Electro &raquo; Feed" href="https://demo2.chethemes.com/electro/feed/" />
<link rel="alternate" type="application/rss+xml" title="Electro &raquo; Comments Feed" href="https://demo2.chethemes.com/electro/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Electro &raquo; Notebook Black Spire V Nitro  VN7-591G Comments Feed" href="https://demo2.chethemes.com/electro/product/notebook-black-spire-v-nitro-vn7-591g/feed/" />
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.6.4' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='photoswipe-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/css/photoswipe/photoswipe.css?ver=3.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/css/photoswipe/default-skin/default-skin.css?ver=3.2.6' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-colorbox-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-compare/assets/css/colorbox.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='electro-fonts-css'  href='//fonts.googleapis.com/css?family=Open+Sans%3A400%2C300%2C600%2C700%2C800%2C800italic%2C700italic%2C600italic%2C400italic%2C300italic&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/bootstrap.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/font-awesome.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/animate.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-electro-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/font-electro.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-style-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/style.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-child-style-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro-child/style.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-color-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/colors/yellow.min.css?ver=1.4.0' type='text/css' media='all' />
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","wc_ajax_url":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/demo2.chethemes.com\/electro\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.2.6'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.2'></script>
<link rel='https://api.w.org/' href='https://demo2.chethemes.com/electro/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://demo2.chethemes.com/electro/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://demo2.chethemes.com/electro/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.3" />
<meta name="generator" content="WooCommerce 3.2.6" />
<link rel="canonical" href="https://demo2.chethemes.com/electro/product/notebook-black-spire-v-nitro-vn7-591g/" />
<link rel='shortlink' href='https://demo2.chethemes.com/electro/?p=2933' />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.6.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-32x32.png" sizes="32x32" />
<link rel="icon" href="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-180x180.png" />
<meta name="msapplication-TileImage" content="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<body class="product-template-default single single-product postid-2933 woocommerce woocommerce-page left-sidebar normal wpb-js-composer js-comp-ver-5.2 vc_responsive">
<div id="page" class="hfeed site">
			<a class="skip-link screen-reader-text" href="#site-navigation">Skip to navigation</a>
		<a class="skip-link screen-reader-text" href="#content">Skip to content</a>
		
		
		<?php include "top-bar.php" ; ?>

		
	<header id="masthead" class="site-header flex-header">
		<div class="container hidden-md-down">
					<div class="row">
					<div class="header-logo">
				<a href="https://demo2.chethemes.com/electro/" class="header-logo-link">
					<svg version="1.1" x="0px" y="0px" width="175.748px"
	height="42.52px" viewBox="0 0 175.748 42.52" enable-background="new 0 0 175.748 42.52">
<ellipse class="ellipse-bg" fill-rule="evenodd" clip-rule="evenodd" fill="#FDD700" cx="170.05" cy="36.341" rx="5.32" ry="5.367"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#333E48" d="M30.514,0.71c-0.034,0.003-0.066,0.008-0.056,0.056
	C30.263,0.995,29.876,1.181,29.79,1.5c-0.148,0.548,0,1.568,0,2.427v36.459c0.265,0.221,0.506,0.465,0.725,0.734h6.187
	c0.2-0.25,0.423-0.477,0.669-0.678V1.387C37.124,1.185,36.9,0.959,36.701,0.71H30.514z M117.517,12.731
	c-0.232-0.189-0.439-0.64-0.781-0.734c-0.754-0.209-2.039,0-3.121,0h-3.176V4.435c-0.232-0.189-0.439-0.639-0.781-0.733
	c-0.719-0.2-1.969,0-3.01,0h-3.01c-0.238,0.273-0.625,0.431-0.725,0.847c-0.203,0.852,0,2.399,0,3.725
	c0,1.393,0.045,2.748-0.055,3.725h-6.41c-0.184,0.237-0.629,0.434-0.725,0.791c-0.178,0.654,0,1.813,0,2.765v2.766
	c0.232,0.188,0.439,0.64,0.779,0.733c0.777,0.216,2.109,0,3.234,0c1.154,0,2.291-0.045,3.176,0.057v21.277
	c0.232,0.189,0.439,0.639,0.781,0.734c0.719,0.199,1.969,0,3.01,0h3.01c1.008-0.451,0.725-1.889,0.725-3.443
	c-0.002-6.164-0.047-12.867,0.055-18.625h6.299c0.182-0.236,0.627-0.434,0.725-0.79c0.176-0.653,0-1.813,0-2.765V12.731z
	 M135.851,18.262c0.201-0.746,0-2.029,0-3.104v-3.104c-0.287-0.245-0.434-0.637-0.781-0.733c-0.824-0.229-1.992-0.044-2.898,0
	c-2.158,0.104-4.506,0.675-5.74,1.411c-0.146-0.362-0.451-0.853-0.893-0.96c-0.693-0.169-1.859,0-2.842,0h-2.842
	c-0.258,0.319-0.625,0.42-0.725,0.79c-0.223,0.82,0,2.338,0,3.443c0,8.109-0.002,16.635,0,24.381
	c0.232,0.189,0.439,0.639,0.779,0.734c0.707,0.195,1.93,0,2.955,0h3.01c0.918-0.463,0.725-1.352,0.725-2.822V36.21
	c-0.002-3.902-0.242-9.117,0-12.473c0.297-4.142,3.836-4.877,8.527-4.686C135.312,18.816,135.757,18.606,135.851,18.262z
	 M14.796,11.376c-5.472,0.262-9.443,3.178-11.76,7.056c-2.435,4.075-2.789,10.62-0.501,15.126c2.043,4.023,5.91,7.115,10.701,7.9
	c6.051,0.992,10.992-1.219,14.324-3.838c-0.687-1.1-1.419-2.664-2.118-3.951c-0.398-0.734-0.652-1.486-1.616-1.467
	c-1.942,0.787-4.272,2.262-7.134,2.145c-3.791-0.154-6.659-1.842-7.524-4.91h19.452c0.146-2.793,0.22-5.338-0.279-7.563
	C26.961,15.728,22.503,11.008,14.796,11.376z M9,23.284c0.921-2.508,3.033-4.514,6.298-4.627c3.083-0.107,4.994,1.976,5.685,4.627
	C17.119,23.38,12.865,23.38,9,23.284z M52.418,11.376c-5.551,0.266-9.395,3.142-11.76,7.056
	c-2.476,4.097-2.829,10.493-0.557,15.069c1.997,4.021,5.895,7.156,10.646,7.957c6.068,1.023,11-1.227,14.379-3.781
	c-0.479-0.896-0.875-1.742-1.393-2.709c-0.312-0.582-1.024-2.234-1.561-2.539c-0.912-0.52-1.428,0.135-2.23,0.508
	c-0.564,0.262-1.223,0.523-1.672,0.676c-4.768,1.621-10.372,0.268-11.537-4.176h19.451c0.668-5.443-0.419-9.953-2.73-13.037
	C61.197,13.388,57.774,11.12,52.418,11.376z M46.622,23.343c0.708-2.553,3.161-4.578,6.242-4.686
	c3.08-0.107,5.08,1.953,5.686,4.686H46.622z M160.371,15.497c-2.455-2.453-6.143-4.291-10.869-4.064
	c-2.268,0.109-4.297,0.65-6.02,1.524c-1.719,0.873-3.092,1.957-4.234,3.217c-2.287,2.519-4.164,6.004-3.902,11.007
	c0.248,4.736,1.979,7.813,4.627,10.326c2.568,2.439,6.148,4.254,10.867,4.064c4.457-0.18,7.889-2.115,10.199-4.684
	c2.469-2.746,4.012-5.971,3.959-11.063C164.949,21.134,162.732,17.854,160.371,15.497z M149.558,33.952
	c-3.246-0.221-5.701-2.615-6.41-5.418c-0.174-0.689-0.26-1.25-0.4-2.166c-0.035-0.234,0.072-0.523-0.045-0.77
	c0.682-3.698,2.912-6.257,6.799-6.547c2.543-0.189,4.258,0.735,5.52,1.863c1.322,1.182,2.303,2.715,2.451,4.967
	C157.789,30.669,154.185,34.267,149.558,33.952z M88.812,29.55c-1.232,2.363-2.9,4.307-6.13,4.402
	c-4.729,0.141-8.038-3.16-8.025-7.563c0.004-1.412,0.324-2.65,0.947-3.726c1.197-2.061,3.507-3.688,6.633-3.612
	c3.222,0.079,4.966,1.708,6.632,3.668c1.328-1.059,2.529-1.948,3.9-2.99c0.416-0.315,1.076-0.688,1.227-1.072
	c0.404-1.031-0.365-1.502-0.891-2.088c-2.543-2.835-6.66-5.377-11.704-5.137c-6.02,0.288-10.218,3.697-12.484,7.846
	c-1.293,2.365-1.951,5.158-1.729,8.408c0.209,3.053,1.191,5.496,2.619,7.508c2.842,4.004,7.385,6.973,13.656,6.377
	c5.976-0.568,9.574-3.936,11.816-8.354c-0.141-0.271-0.221-0.604-0.336-0.902C92.929,31.364,90.843,30.485,88.812,29.55z"/>
</svg>				</a>
			</div>
					<div class="primary-nav animate-dropdown">
			<div class="clearfix">
				 <button class="navbar-toggler hidden-sm-up pull-right flip" type="button" data-toggle="collapse" data-target="#default-header">
				    	&#9776;
				 </button>
			 </div>

			<?php include "nabvar.php" ; ?>
		</div>
				<div class="header-support-info">
			<div class="media">
				<span class="media-left support-icon media-middle"><i class="ec ec-support"></i></span>
				<div class="media-body">
					<span class="support-number"><strong>Support</strong> (+800) 856 800 604</span><br/>
					<span class="support-email">Email: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="6f060109002f0a030a0c1b1d00410c0002">[email&#160;protected]</a></span>
				</div>
			</div>
		</div>		</div><!-- /.row -->
		
		</div>
		
					<div class="container hidden-lg-up">
				<div class="handheld-header">
								<div class="header-logo">
				<a href="https://demo2.chethemes.com/electro/" class="header-logo-link">
					<svg version="1.1" x="0px" y="0px" width="175.748px"
	height="42.52px" viewBox="0 0 175.748 42.52" enable-background="new 0 0 175.748 42.52">
<ellipse class="ellipse-bg" fill-rule="evenodd" clip-rule="evenodd" fill="#FDD700" cx="170.05" cy="36.341" rx="5.32" ry="5.367"/>
<path fill-rule="evenodd" clip-rule="evenodd" fill="#333E48" d="M30.514,0.71c-0.034,0.003-0.066,0.008-0.056,0.056
	C30.263,0.995,29.876,1.181,29.79,1.5c-0.148,0.548,0,1.568,0,2.427v36.459c0.265,0.221,0.506,0.465,0.725,0.734h6.187
	c0.2-0.25,0.423-0.477,0.669-0.678V1.387C37.124,1.185,36.9,0.959,36.701,0.71H30.514z M117.517,12.731
	c-0.232-0.189-0.439-0.64-0.781-0.734c-0.754-0.209-2.039,0-3.121,0h-3.176V4.435c-0.232-0.189-0.439-0.639-0.781-0.733
	c-0.719-0.2-1.969,0-3.01,0h-3.01c-0.238,0.273-0.625,0.431-0.725,0.847c-0.203,0.852,0,2.399,0,3.725
	c0,1.393,0.045,2.748-0.055,3.725h-6.41c-0.184,0.237-0.629,0.434-0.725,0.791c-0.178,0.654,0,1.813,0,2.765v2.766
	c0.232,0.188,0.439,0.64,0.779,0.733c0.777,0.216,2.109,0,3.234,0c1.154,0,2.291-0.045,3.176,0.057v21.277
	c0.232,0.189,0.439,0.639,0.781,0.734c0.719,0.199,1.969,0,3.01,0h3.01c1.008-0.451,0.725-1.889,0.725-3.443
	c-0.002-6.164-0.047-12.867,0.055-18.625h6.299c0.182-0.236,0.627-0.434,0.725-0.79c0.176-0.653,0-1.813,0-2.765V12.731z
	 M135.851,18.262c0.201-0.746,0-2.029,0-3.104v-3.104c-0.287-0.245-0.434-0.637-0.781-0.733c-0.824-0.229-1.992-0.044-2.898,0
	c-2.158,0.104-4.506,0.675-5.74,1.411c-0.146-0.362-0.451-0.853-0.893-0.96c-0.693-0.169-1.859,0-2.842,0h-2.842
	c-0.258,0.319-0.625,0.42-0.725,0.79c-0.223,0.82,0,2.338,0,3.443c0,8.109-0.002,16.635,0,24.381
	c0.232,0.189,0.439,0.639,0.779,0.734c0.707,0.195,1.93,0,2.955,0h3.01c0.918-0.463,0.725-1.352,0.725-2.822V36.21
	c-0.002-3.902-0.242-9.117,0-12.473c0.297-4.142,3.836-4.877,8.527-4.686C135.312,18.816,135.757,18.606,135.851,18.262z
	 M14.796,11.376c-5.472,0.262-9.443,3.178-11.76,7.056c-2.435,4.075-2.789,10.62-0.501,15.126c2.043,4.023,5.91,7.115,10.701,7.9
	c6.051,0.992,10.992-1.219,14.324-3.838c-0.687-1.1-1.419-2.664-2.118-3.951c-0.398-0.734-0.652-1.486-1.616-1.467
	c-1.942,0.787-4.272,2.262-7.134,2.145c-3.791-0.154-6.659-1.842-7.524-4.91h19.452c0.146-2.793,0.22-5.338-0.279-7.563
	C26.961,15.728,22.503,11.008,14.796,11.376z M9,23.284c0.921-2.508,3.033-4.514,6.298-4.627c3.083-0.107,4.994,1.976,5.685,4.627
	C17.119,23.38,12.865,23.38,9,23.284z M52.418,11.376c-5.551,0.266-9.395,3.142-11.76,7.056
	c-2.476,4.097-2.829,10.493-0.557,15.069c1.997,4.021,5.895,7.156,10.646,7.957c6.068,1.023,11-1.227,14.379-3.781
	c-0.479-0.896-0.875-1.742-1.393-2.709c-0.312-0.582-1.024-2.234-1.561-2.539c-0.912-0.52-1.428,0.135-2.23,0.508
	c-0.564,0.262-1.223,0.523-1.672,0.676c-4.768,1.621-10.372,0.268-11.537-4.176h19.451c0.668-5.443-0.419-9.953-2.73-13.037
	C61.197,13.388,57.774,11.12,52.418,11.376z M46.622,23.343c0.708-2.553,3.161-4.578,6.242-4.686
	c3.08-0.107,5.08,1.953,5.686,4.686H46.622z M160.371,15.497c-2.455-2.453-6.143-4.291-10.869-4.064
	c-2.268,0.109-4.297,0.65-6.02,1.524c-1.719,0.873-3.092,1.957-4.234,3.217c-2.287,2.519-4.164,6.004-3.902,11.007
	c0.248,4.736,1.979,7.813,4.627,10.326c2.568,2.439,6.148,4.254,10.867,4.064c4.457-0.18,7.889-2.115,10.199-4.684
	c2.469-2.746,4.012-5.971,3.959-11.063C164.949,21.134,162.732,17.854,160.371,15.497z M149.558,33.952
	c-3.246-0.221-5.701-2.615-6.41-5.418c-0.174-0.689-0.26-1.25-0.4-2.166c-0.035-0.234,0.072-0.523-0.045-0.77
	c0.682-3.698,2.912-6.257,6.799-6.547c2.543-0.189,4.258,0.735,5.52,1.863c1.322,1.182,2.303,2.715,2.451,4.967
	C157.789,30.669,154.185,34.267,149.558,33.952z M88.812,29.55c-1.232,2.363-2.9,4.307-6.13,4.402
	c-4.729,0.141-8.038-3.16-8.025-7.563c0.004-1.412,0.324-2.65,0.947-3.726c1.197-2.061,3.507-3.688,6.633-3.612
	c3.222,0.079,4.966,1.708,6.632,3.668c1.328-1.059,2.529-1.948,3.9-2.99c0.416-0.315,1.076-0.688,1.227-1.072
	c0.404-1.031-0.365-1.502-0.891-2.088c-2.543-2.835-6.66-5.377-11.704-5.137c-6.02,0.288-10.218,3.697-12.484,7.846
	c-1.293,2.365-1.951,5.158-1.729,8.408c0.209,3.053,1.191,5.496,2.619,7.508c2.842,4.004,7.385,6.973,13.656,6.377
	c5.976-0.568,9.574-3.936,11.816-8.354c-0.141-0.271-0.221-0.604-0.336-0.902C92.929,31.364,90.843,30.485,88.812,29.55z"/>
</svg>				</a>
			</div>
					<div class="handheld-navigation-wrapper">
			<div class="handheld-navbar-toggle-buttons clearfix">
				<button class="navbar-toggler navbar-toggle-hamburger hidden-lg-up pull-right flip" type="button">
					<i class="fa fa-bars" aria-hidden="true"></i>
				</button>
				<button class="navbar-toggler navbar-toggle-close hidden-lg-up pull-right flip" type="button">
					<i class="ec ec-close-remove"></i>
				</button>
			</div>

			<div class="handheld-navigation hidden-lg-up" id="default-hh-header">
				<span class="ehm-close">Close</span>
				<ul id="menu-all-departments-menu" class="nav nav-inline yamm"><li id="menu-item-3214" class="highlight menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3214"><a title="Value of the Day" href="https://demo2.chethemes.com/electro/home-v2/">Value of the Day</a></li>
<li id="menu-item-3215" class="highlight menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3215"><a title="Top 100 Offers" href="https://demo2.chethemes.com/electro/home-v3/">Top 100 Offers</a></li>
<li id="menu-item-3216" class="highlight menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3216"><a title="New Arrivals" href="https://demo2.chethemes.com/electro/home-v3-full-color-background/">New Arrivals</a></li>
<li id="menu-item-3094" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3094 dropdown"><a title="Computers &amp; Accessories" href="https://demo2.chethemes.com/electro/product-category/laptops-computers/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Computers &amp; Accessories</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3174" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3174"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="460" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-2.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-2.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-2-300x256.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Computers &amp; Accessories</li>
<li><a href="#">All Computers &amp; Accessories</a></li>
<li><a href="#">Laptops, Desktops &amp; Monitors</a></li>
<li><a href="#">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
<li><a href="#">Printers &amp; Ink</a></li>
<li><a href="#">Networking &amp; Internet Devices</a></li>
<li><a href="#">Computer Accessories</a></li>
<li><a href="#">Software</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Office &amp; Stationery</li>
<li><a href="#">All Office &amp; Stationery</a></li>
<li><a href="#">Pens &amp; Writing</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3095" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3095 dropdown"><a title="Cameras, Audio &amp; Video" href="https://demo2.chethemes.com/electro/product-category/cameras-photography/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Cameras, Audio &amp; Video</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3173" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3173"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="460" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-3.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-3.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-3-300x256.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title"><a href="#">Cameras &amp; Photography</a></li>
<li><a href="#">All Cameras &amp; Photography</a></li>
<li><a href="#">Digital SLRs</a></li>
<li><a href="#">Point &amp; Shoot Cameras</a></li>
<li><a href="#">Lenses</a></li>
<li><a href="#">Camera Accessories</a></li>
<li><a href="#">Security &amp; Surveillance</a></li>
<li><a href="#">Binoculars &amp; Telescopes</a></li>
<li><a href="#">Camcorders</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Audio &amp; Video</li>
<li><a href="#">All Audio &amp; Video</a></li>
<li><a href="#">Headphones &amp; Speakers</a></li>
<li><a href="#">Home Entertainment Systems</a></li>
<li><a href="#">MP3 &amp; Media Players</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3096" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat current-product-ancestor menu-item-has-children animate-dropdown menu-item-3096 dropdown"><a title="Mobiles &amp; Tablets" href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Mobiles &amp; Tablets</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3175" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3175"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left   bg-yamm-extend-outside">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="495" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu--300x275.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Mobiles &amp; Tablets</li>
<li><a href="#">All Mobile Phones</a></li>
<li><a href="#">Smartphones</a></li>
<li><a href="#">Android Mobiles</a></li>
<li><a href="#">Windows Mobiles</a></li>
<li><a href="#">Refurbished Mobiles</a></li>
<li class="nav-divider"></li>
<li><a href="#">All Mobile Accessories</a></li>
<li><a href="#">Cases &amp; Covers</a></li>
<li><a href="#">Screen Protectors</a></li>
<li><a href="#">Power Banks</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title"></li>
<li><a href="#">All Tablets</a></li>
<li><a href="#">Tablet Accessories</a></li>
<li><a href="#">Landline Phones</a></li>
<li><a href="#">Wearable Devices</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3097" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3097 dropdown"><a title="Movies, Music &amp; Video Games" href="https://demo2.chethemes.com/electro/product-category/video-games-consoles/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Movies, Music &amp; Video Games</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3176" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3176"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="485" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-8.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-8.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-8-300x269.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Movies &amp; TV Shows</li>
<li><a href="#">All Movies &amp; TV Shows</a></li>
<li><a href="#">Blu-ray</a></li>
<li><a href="#">All English</a></li>
<li><a href="#">All Hindi</a></li>
<li class="nav-divider"></li>
<li class="nav-title">Video Games</li>
<li><a href="#">All Consoles, Games &amp; Accessories</a></li>
<li><a href="#">PC Games</a></li>
<li><a href="#">Pre-orders &amp; New Releases</a></li>
<li><a href="#">Consoles</a></li>
<li><a href="#">Accessories</a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Music</li>
<li><a href="#">All Music</a></li>
<li><a href="#">International Music</a></li>
<li><a href="#">Film Songs</a></li>
<li><a href="#">Indian Classical</a></li>
<li><a href="#">Musical Instruments</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3098" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3098 dropdown"><a title="TV &amp; Audio" href="https://demo2.chethemes.com/electro/product-category/tv-audio/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">TV &amp; Audio</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3178" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3178"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="460" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-4.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-4.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-4-300x256.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Audio &amp; Video</li>
<li><a href="#">All Audio &amp; Video</a></li>
<li><a href="#">Televisions</a></li>
<li><a href="#">Headphones</a></li>
<li><a href="#">Speakers</a></li>
<li><a href="#">Home Entertainment Systems</a></li>
<li><a href="#">MP3 &amp; Media Players</a></li>
<li><a href="#">Audio &amp; Video Accessories</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">Electro Home Appliances</span><span class="nav-subtext">Available in select cities</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Music</li>
<li><a href="#">Televisions</a></li>
<li><a href="#">Headphones</a></li>
<li><a href="#">Speakers</a></li>
<li><a href="#">Media Players</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3099" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3099 dropdown"><a title="Watches &amp; Eyewear" href="https://demo2.chethemes.com/electro/product-category/gadgets/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Watches &amp; Eyewear</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3177" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3177"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="486" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-7.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-7.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-7-300x270.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Watches</li>
<li><a href="#">All Watches</a></li>
<li><a href="#">Men&#8217;s Watches</a></li>
<li><a href="#">Women&#8217;s Watches</a></li>
<li><a href="#">Premium Watches</a></li>
<li><a href="#">Deals on Watches</a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Eyewear</li>
<li><a href="#">Men&#8217;s Sunglasses</a></li>
<li><a href="#">Women&#8217;s Sunglasses</a></li>
<li><a href="#">Spectacle Frames</a></li>
<li><a href="#">All Sunglasses</a></li>
<li><a href="#">Amazon Fashion</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3100" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3100 dropdown"><a title="Car, Motorbike &amp; Industrial" href="https://demo2.chethemes.com/electro/product-category/car-electronic-gps/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Car, Motorbike &amp; Industrial</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3179" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3179"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="523" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-9.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-9.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-9-300x291.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Car &amp; Motorbike</li>
<li><a href="#">All Cars &amp; Bikes</a></li>
<li><a href="#">Car &amp; Bike Care</a></li>
<li><a href="#">Lubricants</a></li>
<li class="nav-divider"></li>
<li class="nav-title">Shop for Bike</li>
<li><a href="#">Helmets &amp; Gloves</a></li>
<li><a href="#">Bike Parts</a></li>
<li class="nav-title">Shop for Car</li>
<li><a href="#">Air Fresheners</a></li>
<li><a href="#">Car Parts</a></li>
<li><a href="#">Tyre Accessories</a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Industrial Supplies</li>
<li><a href="#">All Industrial Supplies</a></li>
<li><a href="#">Lab &amp; Scientific</a></li>
<li><a href="#">Janitorial &amp; Sanitation Supplies</a></li>
<li><a href="#">Test, Measure &amp; Inspect</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3101" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3101 dropdown"><a title="Accessories" href="https://demo2.chethemes.com/electro/product-category/laptops-computers/accessories-laptops-computers/" data-toggle="dropdown" class="dropdown-toggle" aria-haspopup="true">Accessories</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3113" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3113"><a title="Cases" href="https://demo2.chethemes.com/electro/product-category/accessories/cases/">Cases</a></li>
	<li id="menu-item-3114" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3114"><a title="Chargers" href="https://demo2.chethemes.com/electro/product-category/accessories/chargers/">Chargers</a></li>
	<li id="menu-item-3115" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3115"><a title="Headphone Accessories" href="https://demo2.chethemes.com/electro/product-category/accessories/headphone-accessories/">Headphone Accessories</a></li>
	<li id="menu-item-3116" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3116"><a title="Headphone Cases" href="https://demo2.chethemes.com/electro/product-category/accessories/headphone-cases/">Headphone Cases</a></li>
	<li id="menu-item-3117" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3117"><a title="Headphones" href="https://demo2.chethemes.com/electro/product-category/accessories/headphones/">Headphones</a></li>
	<li id="menu-item-3118" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3118"><a title="Computer Accessories" href="https://demo2.chethemes.com/electro/product-category/laptops-computers/accessories-laptops-computers/">Computer Accessories</a></li>
	<li id="menu-item-3119" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3119"><a title="Laptop Accessories" href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/accessories-smart-phones-tablets/">Laptop Accessories</a></li>
</ul>
</li>
</ul>			</div>
		</div>
						</div>
			</div>
				
	</header><!-- #masthead -->

			<nav class="navbar navbar-primary navbar-full hidden-md-down" style="background-color:#0787ea;">
			<div class="container">
						<ul class="nav navbar-nav departments-menu animate-dropdown">
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" id="departments-menu-toggle">
					Shop By Department				</a>
				<ul id="menu-vertical-menu" class="dropdown-menu yamm departments-menu-dropdown"><li id="menu-item-3211" class="highlight menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3211"><a title="Value of the Day" href="https://demo2.chethemes.com/electro/home-v2/">Value of the Day</a></li>
<li id="menu-item-3212" class="highlight menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3212"><a title="Top 100 Offers" href="https://demo2.chethemes.com/electro/home-v3/">Top 100 Offers</a></li>
<li id="menu-item-3213" class="highlight menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3213"><a title="New Arrivals" href="https://demo2.chethemes.com/electro/home-v3-full-color-background/">New Arrivals</a></li>
<li id="menu-item-3071" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3071 dropdown-submenu"><a title="Computers &amp; Accessories" href="https://demo2.chethemes.com/electro/product-category/laptops-computers/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">Computers &amp; Accessories</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3218" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3218"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content bg-yamm-content-bottom bg-yamm-content-right"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="460" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-2.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-2.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-2-300x256.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Computers &amp; Accessories</li>
<li><a href="#">All Computers &amp; Accessories</a></li>
<li><a href="#">Laptops, Desktops &amp; Monitors</a></li>
<li><a href="#">Pen Drives, Hard Drives &amp; Memory Cards</a></li>
<li><a href="#">Printers &amp; Ink</a></li>
<li><a href="#">Networking &amp; Internet Devices</a></li>
<li><a href="#">Computer Accessories</a></li>
<li><a href="#">Software</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Office &amp; Stationery</li>
<li><a href="#">All Office &amp; Stationery</a></li>
<li><a href="#">Pens &amp; Writing</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3072" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3072 dropdown-submenu"><a title="Cameras, Audio &amp; Video" href="https://demo2.chethemes.com/electro/product-category/cameras-photography/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">Cameras, Audio &amp; Video</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3217" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3217"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="460" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-3.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-3.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-3-300x256.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title"><a href="#">Cameras &amp; Photography</a></li>
<li><a href="#">All Cameras &amp; Photography</a></li>
<li><a href="#">Digital SLRs</a></li>
<li><a href="#">Point &amp; Shoot Cameras</a></li>
<li><a href="#">Lenses</a></li>
<li><a href="#">Camera Accessories</a></li>
<li><a href="#">Security &amp; Surveillance</a></li>
<li><a href="#">Binoculars &amp; Telescopes</a></li>
<li><a href="#">Camcorders</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Audio &amp; Video</li>
<li><a href="#">All Audio &amp; Video</a></li>
<li><a href="#">Headphones &amp; Speakers</a></li>
<li><a href="#">Home Entertainment Systems</a></li>
<li><a href="#">MP3 &amp; Media Players</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3073" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat current-product-ancestor menu-item-has-children animate-dropdown menu-item-3073 dropdown-submenu"><a title="Mobiles &amp; Tablets" href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">Mobiles &amp; Tablets</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3219" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3219"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left   bg-yamm-extend-outside">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="495" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu--300x275.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Mobiles &amp; Tablets</li>
<li><a href="#">All Mobile Phones</a></li>
<li><a href="#">Smartphones</a></li>
<li><a href="#">Android Mobiles</a></li>
<li><a href="#">Windows Mobiles</a></li>
<li><a href="#">Refurbished Mobiles</a></li>
<li class="nav-divider"></li>
<li><a href="#">All Mobile Accessories</a></li>
<li><a href="#">Cases &amp; Covers</a></li>
<li><a href="#">Screen Protectors</a></li>
<li><a href="#">Power Banks</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">All Electronics</span><span class="nav-subtext">Discover more products</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title"></li>
<li><a href="#">All Tablets</a></li>
<li><a href="#">Tablet Accessories</a></li>
<li><a href="#">Landline Phones</a></li>
<li><a href="#">Wearable Devices</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3074" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3074 dropdown-submenu"><a title="Movies, Music &amp; Video Games" href="https://demo2.chethemes.com/electro/product-category/video-games-consoles/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">Movies, Music &amp; Video Games</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3220" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3220"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="485" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-8.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-8.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-8-300x269.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Movies &amp; TV Shows</li>
<li><a href="#">All Movies &amp; TV Shows</a></li>
<li><a href="#">Blu-ray</a></li>
<li><a href="#">All English</a></li>
<li><a href="#">All Hindi</a></li>
<li class="nav-divider"></li>
<li class="nav-title">Video Games</li>
<li><a href="#">All Consoles, Games &amp; Accessories</a></li>
<li><a href="#">PC Games</a></li>
<li><a href="#">Pre-orders &amp; New Releases</a></li>
<li><a href="#">Consoles</a></li>
<li><a href="#">Accessories</a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Music</li>
<li><a href="#">All Music</a></li>
<li><a href="#">International Music</a></li>
<li><a href="#">Film Songs</a></li>
<li><a href="#">Indian Classical</a></li>
<li><a href="#">Musical Instruments</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3075" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3075 dropdown-submenu"><a title="TV &amp; Audio" href="https://demo2.chethemes.com/electro/product-category/tv-audio/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">TV &amp; Audio</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3221" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3221"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="460" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-4.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-4.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-4-300x256.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Audio &amp; Video</li>
<li><a href="#">All Audio &amp; Video</a></li>
<li><a href="#">Televisions</a></li>
<li><a href="#">Headphones</a></li>
<li><a href="#">Speakers</a></li>
<li><a href="#">Home Entertainment Systems</a></li>
<li><a href="#">MP3 &amp; Media Players</a></li>
<li><a href="#">Audio &amp; Video Accessories</a></li>
<li class="nav-divider"></li>
<li><a href="#"><span class="nav-text">Electro Home Appliances</span><span class="nav-subtext">Available in select cities</span></a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Music</li>
<li><a href="#">Televisions</a></li>
<li><a href="#">Headphones</a></li>
<li><a href="#">Speakers</a></li>
<li><a href="#">Media Players</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3076" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3076 dropdown-submenu"><a title="Watches &amp; Eyewear" href="https://demo2.chethemes.com/electro/product-category/gadgets/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">Watches &amp; Eyewear</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3222" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3222"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="486" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-7.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-7.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-7-300x270.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Watches</li>
<li><a href="#">All Watches</a></li>
<li><a href="#">Men&#8217;s Watches</a></li>
<li><a href="#">Women&#8217;s Watches</a></li>
<li><a href="#">Premium Watches</a></li>
<li><a href="#">Deals on Watches</a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Eyewear</li>
<li><a href="#">Men&#8217;s Sunglasses</a></li>
<li><a href="#">Women&#8217;s Sunglasses</a></li>
<li><a href="#">Spectacle Frames</a></li>
<li><a href="#">All Sunglasses</a></li>
<li><a href="#">Amazon Fashion</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3077" class="yamm-tfw menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-has-children animate-dropdown menu-item-3077 dropdown-submenu"><a title="Car, Motorbike &amp; Industrial" href="https://demo2.chethemes.com/electro/product-category/car-electronic-gps/" data-toggle="dropdown-hover" class="dropdown-toggle" aria-haspopup="true">Car, Motorbike &amp; Industrial</a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-3223" class="menu-item menu-item-type-post_type menu-item-object-static_block animate-dropdown menu-item-3223"><div class="yamm-content"><div class="vc_row wpb_row vc_row-fluid bg-yamm-content"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div  class="wpb_single_image wpb_content_element vc_align_left">
		
		<figure class="wpb_wrapper vc_figure">
			<div class="vc_single_image-wrapper   vc_box_border_grey"><img width="540" height="523" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-9.png" class="vc_single_image-img attachment-full" alt="" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-9.png 540w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/megamenu-9-300x291.png 300w" sizes="(max-width: 540px) 100vw, 540px" /></div>
		</figure>
	</div>
</div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Car &amp; Motorbike</li>
<li><a href="#">All Cars &amp; Bikes</a></li>
<li><a href="#">Car &amp; Bike Care</a></li>
<li><a href="#">Lubricants</a></li>
<li class="nav-divider"></li>
<li class="nav-title">Shop for Bike</li>
<li><a href="#">Helmets &amp; Gloves</a></li>
<li><a href="#">Bike Parts</a></li>
<li class="nav-title">Shop for Car</li>
<li><a href="#">Air Fresheners</a></li>
<li><a href="#">Car Parts</a></li>
<li><a href="#">Tyre Accessories</a></li>
</ul>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<ul>
<li class="nav-title">Industrial Supplies</li>
<li><a href="#">All Industrial Supplies</a></li>
<li><a href="#">Lab &amp; Scientific</a></li>
<li><a href="#">Janitorial &amp; Sanitation Supplies</a></li>
<li><a href="#">Test, Measure &amp; Inspect</a></li>
</ul>

		</div>
	</div>
</div></div></div></div>
</div></li>
</ul>
</li>
<li id="menu-item-3078" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3078"><a title="Accessories" href="https://demo2.chethemes.com/electro/product-category/laptops-computers/accessories-laptops-computers/">Accessories</a></li>
<li id="menu-item-3079" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3079"><a title="Printers &amp; Ink" href="https://demo2.chethemes.com/electro/product-category/printers-ink/">Printers &amp; Ink</a></li>
<li id="menu-item-3080" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3080"><a title="Software" href="https://demo2.chethemes.com/electro/product-category/software/">Software</a></li>
<li id="menu-item-3081" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3081"><a title="Office Supplies" href="https://demo2.chethemes.com/electro/product-category/office-supplies/">Office Supplies</a></li>
<li id="menu-item-3082" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3082"><a title="Computer Components" href="https://demo2.chethemes.com/electro/product-category/computer-components/">Computer Components</a></li>
<li id="menu-item-3083" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3083"><a title="Car Electronic &amp; GPS" href="https://demo2.chethemes.com/electro/product-category/car-electronic-gps/">Car Electronic &amp; GPS</a></li>
<li id="menu-item-3084" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3084"><a title="Accessories" href="https://demo2.chethemes.com/electro/product-category/laptops-computers/accessories-laptops-computers/">Accessories</a></li>
<li id="menu-item-3085" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat animate-dropdown menu-item-3085"><a title="Printers &amp; Ink" href="https://demo2.chethemes.com/electro/product-category/printers-ink/">Printers &amp; Ink</a></li>
</ul>			</li>
		</ul>
		
<form class="navbar-search" method="get" action="https://demo2.chethemes.com/electro/">
	<label class="sr-only screen-reader-text" for="search">Search for:</label>
	<div class="input-group">
    	<div class="input-search-field">
    		<input type="text" id="search" class="form-control search-field product-search-field" dir="ltr" value="" name="s" placeholder="Search for Products" />
    	</div>
    			<div class="input-group-addon search-categories">
			<select  name='product_cat' id='product_cat' class='postform resizeselect' >
	<option value='0' selected='selected'>All Categories</option>
	<option class="level-0" value="home-entertainment">Home Entertainment</option>
	<option class="level-0" value="laptops-computers">Laptops &amp; Computers</option>
	<option class="level-0" value="cameras-photography">Cameras &amp; Photography</option>
	<option class="level-0" value="smart-phones-tablets">Smart Phones &amp; Tablets</option>
	<option class="level-0" value="video-games-consoles">Video Games &amp; Consoles</option>
	<option class="level-0" value="tv-audio">TV &amp; Audio</option>
	<option class="level-0" value="gadgets">Gadgets</option>
	<option class="level-0" value="printers-ink">Printers &amp; Ink</option>
	<option class="level-0" value="computer-components">Computer Components</option>
	<option class="level-0" value="accessories">Accessories</option>
</select>
		</div>
				<div class="input-group-btn">
			<input type="hidden" id="search-param" name="post_type" value="product" />
			<button type="submit" class="btn btn-secondary"><i class="ec ec-search"></i></button>
		</div>
	</div>
</form>

<ul class="navbar-mini-cart navbar-nav animate-dropdown nav pull-right flip">
	<li class="nav-item dropdown">
		<a href="https://demo2.chethemes.com/electro/cart/" class="nav-link" data-toggle="dropdown">
			<i class="ec ec-shopping-bag"></i>
			<span class="cart-items-count count">0</span>
			<span class="cart-items-total-price total-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>0.00</span></span>
		</a>
		<ul class="dropdown-menu dropdown-menu-mini-cart">
			<li>
				<div class="widget_shopping_cart_content">
				  

	<p class="woocommerce-mini-cart__empty-message">No products in the cart.</p>


				</div>
			</li>
		</ul>
	</li>
</ul>

			<ul class="navbar-wishlist nav navbar-nav pull-right flip">
				<li class="nav-item">
					<a href="https://demo2.chethemes.com/electro/wishlist/" class="nav-link">
						<i class="ec ec-favorites"></i>
											</a>
				</li>
			</ul>
						<ul class="navbar-compare nav navbar-nav pull-right flip">
				<li class="nav-item">
					<a href="https://demo2.chethemes.com/electro/compare/" class="nav-link">
						<i class="ec ec-compare"></i>
											</a>
				</li>
			</ul>
						</div>
		</nav>
		
	<div id="content" class="site-content" tabindex="-1">
		<div class="container">

		<nav class="woocommerce-breadcrumb"><a href="https://demo2.chethemes.com/electro">Home</a><span class="delimiter"><i class="fa fa-angle-right"></i></span><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/">Smart Phones &amp; Tablets</a><span class="delimiter"><i class="fa fa-angle-right"></i></span><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/">Smartphones</a><span class="delimiter"><i class="fa fa-angle-right"></i></span>Notebook Black Spire V Nitro  VN7-591G</nav>
			<div id="primary" class="content-area">
			<main id="main" class="site-main">
			
		
			

<div id="product-2933" class="post-2933 product type-product status-publish has-post-thumbnail product_cat-smartphones pa_brands-samsung first instock sale shipping-taxable purchasable product-type-simple">

			<div class="single-product-wrapper">
				<div class="product-images-wrapper">
		
	<span class="onsale">Sale!</span>
<div class="woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-5 images" data-columns="5" style="opacity: 0; transition: opacity .25s ease-in-out;">
	<figure class="woocommerce-product-gallery__wrapper">
		<div data-thumb="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg" class="woocommerce-product-gallery__image"><a href="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone.jpg"><img width="470" height="470" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-600x600.jpg" class="attachment-shop_single size-shop_single wp-post-image" alt="" title="GoldPhone" data-caption="" data-src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone.jpg" data-large_image="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone.jpg" data-large_image_width="720" data-large_image_height="660" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-600x600.jpg 600w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-150x150.jpg 150w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg 180w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-300x300.jpg 300w" sizes="(max-width: 470px) 100vw, 470px" /></a></div>	</figure>
</div>
		</div><!-- /.product-images-wrapper -->
		
	<div class="summary entry-summary">

		<span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span><h1 class="product_title entry-title">Notebook Black Spire V Nitro  VN7-591G</h1>
	<div class="woocommerce-product-rating">
		<div class="star-rating"><span style="width:100%">Rated <strong class="rating">5.00</strong> out of 5 based on <span class="rating">3</span> customer ratings</span></div>		<a href="#reviews" class="woocommerce-review-link" rel="nofollow">(<span class="count">3</span> customer reviews)</a>	</div>

		<div class="brand">
			<a href="https://demo2.chethemes.com/electro/brands/samsung/"><img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/themeforest.png" alt="Samsung" /></a>		</div>
		
			<div class="availability">
				Availability: <span class="electro-stock-availability"><p class="stock in-stock">2 in stock</p></span>
			</div>

				<hr class="single-product-title-divider" />
		<div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2933">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2933" rel="nofollow" data-product-id="2933" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2933" class="add-to-compare-link" data-product_id="2933">Compare</a></div>
<div class="woocommerce-product-details__short-description">
    <ul>
<li>4.5 inch HD Screen</li>
<li>Android 4.4 KitKat OS</li>
<li>1.4 GHz Quad Core™ Processor</li>
<li>20 MP front Camera</li>
</ul>
</div>
<p class="price"><span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,299.00</span></del></span></p>
<p class="stock in-stock">2 in stock</p>

	
	<form class="cart" method="post" enctype='multipart/form-data'>
			<div class="quantity">
		<label for="quantity_5a815aef74a9d">Quantity:</label>
		<input type="number" id="quantity_5a815aef74a9d" class="input-text qty text" step="1" min="1" max="2" name="quantity" value="1" title="Qty" size="4" pattern="[0-9]*" inputmode="numeric" aria-labelledby="" />
	</div>
	
		<button type="submit" name="add-to-cart" value="2933" class="single_add_to_cart_button button alt">Add to cart</button>

			</form>

	

	</div><!-- .summary -->

			</div><!-- /.single-product-wrapper -->
		
	<div class="woocommerce-tabs wc-tabs-wrapper">
		<ul class="tabs wc-tabs" role="tablist">
							<li class="accessories_tab" id="tab-title-accessories" role="tab" aria-controls="tab-accessories">
					<a href="#tab-accessories">Accessories</a>
				</li>
							<li class="description_tab" id="tab-title-description" role="tab" aria-controls="tab-description">
					<a href="#tab-description">Description</a>
				</li>
							<li class="specification_tab" id="tab-title-specification" role="tab" aria-controls="tab-specification">
					<a href="#tab-specification">Specification</a>
				</li>
							<li class="reviews_tab" id="tab-title-reviews" role="tab" aria-controls="tab-reviews">
					<a href="#tab-reviews">Reviews</a>
				</li>
					</ul>
					<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--accessories panel entry-content wc-tab" id="tab-accessories" role="tabpanel" aria-labelledby="tab-title-accessories">
				
	<div class="accessories">

		<div class="electro-wc-message"></div>
		<div class="row">
			<div class="col-xs-12 col-sm-9 col-left">

				<ul class="products columns-3">
					<li class="post-2933 product first">
						<div class="product-outer">
							<div class="product-inner">
								<span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span>								<a href="https://demo2.chethemes.com/electro/product/notebook-black-spire-v-nitro-vn7-591g/">
									<h3>Notebook Black Spire V Nitro  VN7-591G</h3>
									<div class="product-thumbnail">
										<img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" />									</div>
								</a>
								<div class="price-add-to-cart"><p class="price"><span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#036;</span>1,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#036;</span>2,299.00</span></del></span></p></div>
							</div>
						</div>					
					</li>

					
					
					
						<li class="post-2630 product type-product status-publish has-post-thumbnail product_cat-smartwatches  instock shipping-taxable purchasable product-type-simple">
	<div class="product-outer"><div class="product-inner"><span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/gadgets/smartwatches/" rel="tag">Smartwatches</a></span><a href="https://demo2.chethemes.com/electro/product/smartwatch-2-0-lte-wifi-waterproof/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><h2 class="woocommerce-loop-product__title">Smartwatch 2.0 LTE Wifi  Waterproof</h2><div class="product-thumbnail"><img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartwatch2-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" /></div></a><div class="price-add-to-cart">
	<span class="price"><span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>725.00</span></span></span>
<div class="add-to-cart-wrap" data-toggle="tooltip" data-title="Add to cart"><a rel="nofollow" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add-to-cart=2630" data-quantity="1" data-product_id="2630" data-product_sku="5487FB8/10" class="button product_type_simple add_to_cart_button ajax_add_to_cart">Add to cart</a></div></div><!-- /.price-add-to-cart --><div class="hover-area"><div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2630">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2630" rel="nofollow" data-product-id="2630" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2630" class="add-to-compare-link" data-product_id="2630">Compare</a></div></div></div><!-- /.product-inner --></div><!-- /.product-outer --></li>

						
					
						<li class="post-2440 product type-product status-publish has-post-thumbnail product_cat-headphone-cases pa_brands-apple last instock shipping-taxable purchasable product-type-simple">
	<div class="product-outer"><div class="product-inner"><span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/accessories/headphone-cases/" rel="tag">Headphone Cases</a></span><a href="https://demo2.chethemes.com/electro/product/universal-headphones-case-in-black/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><h2 class="woocommerce-loop-product__title">Universal Headphones Case in Black</h2><div class="product-thumbnail"><img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/headphone-case-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" /></div></a><div class="price-add-to-cart">
	<span class="price"><span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>159.00</span></span></span>
<div class="add-to-cart-wrap" data-toggle="tooltip" data-title="Add to cart"><a rel="nofollow" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add-to-cart=2440" data-quantity="1" data-product_id="2440" data-product_sku="5487FB8/28" class="button product_type_simple add_to_cart_button ajax_add_to_cart">Add to cart</a></div></div><!-- /.price-add-to-cart --><div class="hover-area"><div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2440">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2440" rel="nofollow" data-product-id="2440" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2440" class="add-to-compare-link" data-product_id="2440">Compare</a></div></div></div><!-- /.product-inner --></div><!-- /.product-outer --></li>

						
					
				</ul>
				
				<div class="check-products">
					<div class="checkbox accessory-checkbox"><label><input checked disabled type="checkbox" class="product-check" data-price="1999" data-product-id="2933" data-product-type="simple" /> <span class="product-title"><strong>This product: </strong>Notebook Black Spire V Nitro  VN7-591G</span> - <span class="accessory-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,999.00</span></span></label></div><div class="checkbox accessory-checkbox"><label><input checked type="checkbox" class="product-check" data-price="725" data-product-id="2630" data-product-type="simple" /> <span class="product-title">Smartwatch 2.0 LTE Wifi  Waterproof</span> - <span class="accessory-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>725.00</span></span></label></div><div class="checkbox accessory-checkbox"><label><input checked type="checkbox" class="product-check" data-price="159" data-product-id="2440" data-product-type="simple" /> <span class="product-title">Universal Headphones Case in Black</span> - <span class="accessory-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>159.00</span></span></label></div>				</div>

			</div>

			<div class="col-xs-12 col-sm-3 col-right">
				<div class="total-price">
					<span class="total-price-html"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#036;</span>2,883.00</span></span> for <span class="total-products">3</span> item(s)				</div>
				<div class="accessories-add-all-to-cart">
					<button type="button" class="button btn btn-primary add-all-to-cart">Add all to cart</button>
				</div>
			</div>
		</div>
				<script data-cfasync="false" src="/cdn-cgi/scripts/d07b1474/cloudflare-static/email-decode.min.js"></script><script type="text/javascript">
			jQuery(document).ready(function($) {

				function accessory_checked_count(){
					var product_count = 0;
					$('.accessory-checkbox .product-check').each(function() {
						if( $(this).is(':checked') ) {
							if( $(this).data( 'price' ) !== '' ) {
								product_count++;
							}
						}
					});
					return product_count;
				}

				function accessory_checked_total_price(){
					var total_price = 0;
					$('.accessory-checkbox .product-check').each(function() {
						if( $(this).is(':checked') ) {
							if( $(this).data( 'price' ) !== '' ) {
								total_price += parseFloat( $(this).data( 'price' ) );
							}
						}
					});
					return total_price;
				}

				function accessory_checked_product_ids(){
					var product_ids = [];
					$('.accessory-checkbox .product-check').each(function() {
						if( $(this).is(':checked') ) {
							product_ids.push( $(this).data( 'product-id' ) );
						}
					});
					return product_ids;
				}

				function accessory_unchecked_product_ids(){
					var product_ids = [];
					$('.accessory-checkbox .product-check').each(function() {
						if( ! $(this).is(':checked') ) {
							product_ids.push( $(this).data( 'product-id' ) );
						}
					});
					return product_ids;
				}

				function accessory_checked_variable_product_ids(){
					var variable_product_ids = [];
					$('.accessory-checkbox .product-check').each(function() {
						if( $(this).is(':checked') && $(this).data( 'product-type' ) == 'variable' ) {
							variable_product_ids.push( $(this).data( 'product-id' ) );
						}
					});
					return variable_product_ids;
				}

				function accessory_is_variation_selected(){
					if( $(".single_add_to_cart_button").is(":disabled") ) {
						return false;
					}
					return true;
				}

				function accessory_is_variation_available(){
					if( $(".single_add_to_cart_button").length === 0 || $(".single_add_to_cart_button").hasClass("disabled") || $(".single_add_to_cart_button").hasClass("wc-variation-is-unavailable") ) {
						return false;
					}
					return true;
				}

				function accessory_is_product_available(){
					if( $(".single_add_to_cart_button").length === 0 || $(".single_add_to_cart_button").hasClass("disabled") ) {
						return false;
					}
					return true;
				}

				function accessory_refresh_fragments( response ){
					var this_page = window.location.toString();
					var fragments = response.fragments;
					var cart_hash = response.cart_hash;

					// Block fragments class
					if ( fragments ) {
						$.each( fragments, function( key ) {
							$( key ).addClass( 'updating' );
						});
					}

					// Replace fragments
					if ( fragments ) {
						$.each( fragments, function( key, value ) {
							$( key ).replaceWith( value );
						});
					}

					// Cart page elements
					$( '.shop_table.cart' ).load( this_page + ' .shop_table.cart:eq(0) > *', function() {

						$( '.shop_table.cart' ).stop( true ).css( 'opacity', '1' ).unblock();

						$( document.body ).trigger( 'cart_page_refreshed' );
					});

					$( '.cart_totals' ).load( this_page + ' .cart_totals:eq(0) > *', function() {
						$( '.cart_totals' ).stop( true ).css( 'opacity', '1' ).unblock();
					});
				}

				$( 'body' ).on( 'found_variation', function( event, variation ) {
					$('.accessory-checkbox .product-check').each(function() {
						if( $(this).is(':checked') && $(this).data( 'product-type' ) == 'variable' ) {
							$(this).data( 'price', variation.display_price );
							$(this).siblings( 'span.accessory-price' ).html( $(variation.price_html).html() );
						}
					});
				});

				$( 'body' ).on( 'woocommerce_variation_has_changed', function( event ) {
					var total_price = accessory_checked_total_price();
					$.ajax({
						type: "POST",
						async: false,
						url: "https://demo2.chethemes.com/electro/wp-admin/admin-ajax.php",
						data: { 'action': "electro_accessories_total_price", 'price': total_price  },
						success : function( response ) {
							$( 'span.total-price-html .amount' ).html( response );
							$( 'span.total-products' ).html( accessory_checked_count() );
						}
					})
				});

				$( '.accessory-checkbox .product-check' ).on( "click", function() {
					var total_price = accessory_checked_total_price();
					$.ajax({
						type: "POST",
						async: false,
						url: "https://demo2.chethemes.com/electro/wp-admin/admin-ajax.php",
						data: { 'action': "electro_accessories_total_price", 'price': total_price  },
						success : function( response ) {
							$( 'span.total-price-html .amount' ).html( response );
							$( 'span.total-products' ).html( accessory_checked_count() );

							var unchecked_product_ids = accessory_unchecked_product_ids();
							$( '.accessories ul.products > li' ).each(function() {
								$(this).show();
								for (var i = 0; i < unchecked_product_ids.length; i++ ) {
									if( $(this).hasClass( 'post-'+unchecked_product_ids[i] ) ) {
										$(this).hide();
									}
								}
							});
						}
					})
				});

				$('.accessories-add-all-to-cart .add-all-to-cart').click(function() {
					var accerories_all_product_ids = accessory_checked_product_ids();
					var accerories_variable_product_ids = accessory_checked_variable_product_ids();
					if( accerories_all_product_ids.length === 0 ) {
						var accerories_alert_msg = '<div class="woocommerce-error">No Products selected.</div>';
					} else if( accerories_variable_product_ids.length > 0 && accessory_is_variation_selected() === false ) {
						var accerories_alert_msg = '<div class="woocommerce-error">Product Variation does not selected.</div>';
					} else if( accerories_variable_product_ids.length > 0 && accessory_is_variation_available() === false ) {
						var accerories_alert_msg = '<div class="woocommerce-error">Sorry, this product is unavailable.</div>';
					} else if( accerories_variable_product_ids.length === 0 && accessory_is_product_available() === false ) {
						var accerories_alert_msg = '<div class="woocommerce-error">Sorry, this product is unavailable.</div>';
					} else {
						for (var i = 0; i < accerories_all_product_ids.length; i++ ) {
							if( ! $.inArray( accerories_all_product_ids[i], accerories_variable_product_ids ) ) {
								var variation_id  = $('.variations_form .variations_button').find('input[name^=variation_id]').val();
								var variation = {};
								if( $( '.variations_form' ).find('select[name^=attribute]').length ) {
									$( '.variations_form' ).find('select[name^=attribute]').each(function() {
										var attribute = $(this).attr("name");
										var attributevalue = $(this).val();
										variation[attribute] = attributevalue;
									});

								} else {

									$( '.variations_form' ).find('.select').each(function() {
										var attribute = $(this).attr("data-attribute-name");
										var attributevalue = $(this).find('.selected').attr('data-name');
										variation[attribute] = attributevalue;
									});

								}
								$.ajax({
									type: "POST",
									async: false,
									url: "https://demo2.chethemes.com/electro/wp-admin/admin-ajax.php",
									data: { 'action': "electro_variable_add_to_cart", 'product_id': accerories_all_product_ids[i], 'variation_id': variation_id, 'variation': variation  },
									success : function( response ) {
										accessory_refresh_fragments( response );
									}
								})
							} else {
								$.ajax({
									type: "POST",
									async: false,
									url: "https://demo2.chethemes.com/electro/wp-admin/admin-ajax.php",
									data: { 'action': "woocommerce_add_to_cart", 'product_id': accerories_all_product_ids[i]  },
									success : function( response ) {
										accessory_refresh_fragments( response );
									}
								})
							}
						}
						var accerories_alert_msg = '<div class="woocommerce-message">Products was successfully added to your cart. <a class="button wc-forward" href="https://demo2.chethemes.com/electro/cart/">View Cart</a></div>';
					}
					$( '.electro-wc-message' ).html(accerories_alert_msg);
				});

			});
		</script>

	</div>

			</div>
					<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--description panel entry-content wc-tab" id="tab-description" role="tabpanel" aria-labelledby="tab-title-description">
				<div class="electro-description">

<p>&nbsp;</p>
<p><img class="alignnone wp-image-2995 size-large" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_title_2x-1024x346.png" alt="overview_hero_title_2x" width="1024" height="346" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_title_2x-1024x346.png 1024w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_title_2x-300x101.png 300w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_title_2x-768x259.png 768w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_title_2x.png 1600w" sizes="(max-width: 1024px) 100vw, 1024px" /></p>
<p><img class="alignnone wp-image-2994 size-large" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_2x-e1459776153284-1024x430.jpg" alt="overview_hero_2x" width="1024" height="430" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_2x-e1459776153284-1024x430.jpg 1024w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_2x-e1459776153284-300x126.jpg 300w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/overview_hero_2x-e1459776153284-768x322.jpg 768w" sizes="(max-width: 1024px) 100vw, 1024px" /></p>
<p>A groundbreaking Retina display. Powerful dual-core and quad-core Intel processors. Fast flash storage. High-performance graphics. Great built-in apps. And now in the 13-inch model, a revolutionary new Force Touch trackpad and even longer battery life.1 Whatever you can imagine, MacBook Pro with Retina display gives you the power to create.</p>
<p>The design of MacBook Pro packs a lot of power into not a lot of space. Because we believe that high performance shouldn’t come at the expense of portability. And despite being so compact, the new 13-inch and 15-inch MacBook Pro with Retina display models now deliver up to 10 hours and nine hours of battery life, respectively — an hour more than the previous models.</p>
<p><img class="alignnone wp-image-2993 size-full" src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/hero_large_2x.jpg" alt="hero_large_2x" width="1956" height="724" srcset="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/hero_large_2x.jpg 1956w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/hero_large_2x-300x111.jpg 300w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/hero_large_2x-768x284.jpg 768w, https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/hero_large_2x-1024x379.jpg 1024w" sizes="(max-width: 1956px) 100vw, 1956px" /></p>
<p>With Multi-Touch in OS X, you can use realistic gestures like swiping or pinching to switch between apps, navigate your content and get the most out of your desktop space.</p>
<p>The new Force Touch trackpad takes all the capabilities of Multi-Touch and adds force sensors that detect subtle differences in the amount of downward pressure you apply. This lets you have a deeper connection to your content, bringing more functionality to your fingertip. It also introduces haptic feedback to MacBook Pro — allowing you to not just see what’s happening on the screen, but to feel it.</p>
</div><div class="product_meta">

	
	
		<span class="sku_wrapper">SKU: <span class="sku">5487FB8/22</span></span>

	
	<span class="posted_in">Category: <a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span>
	
	
</div>
			</div>
					<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--specification panel entry-content wc-tab" id="tab-specification" role="tabpanel" aria-labelledby="tab-title-specification">
				<h3>Technical Specifications</h3>
<table class="table">
<tbody>
<tr>
<td>Brand</td>
<td>Apple</td>
</tr>
<tr>
<td>Item Height</td>
<td>18 Millimeters</td>
</tr>
<tr>
<td>Item Width</td>
<td>31.4 Centimeters</td>
</tr>
<tr>
<td>Screen Size</td>
<td>13 Inches</td>
</tr>
<tr class="size-weight">
<td>Item Weight</td>
<td>1.6 Kg</td>
</tr>
<tr class="size-weight">
<td>Product Dimensions</td>
<td>21.9 x 31.4 x 1.8 cm</td>
</tr>
<tr class="item-model-number">
<td>Item model number</td>
<td>MF841HN/A</td>
</tr>
<tr>
<td>Processor Brand</td>
<td>Intel</td>
</tr>
<tr>
<td>Processor Type</td>
<td>Core i5</td>
</tr>
<tr>
<td>Processor Speed</td>
<td>2.9 GHz</td>
</tr>
<tr>
<td>RAM Size</td>
<td>8 GB</td>
</tr>
<tr>
<td>Hard Drive Size</td>
<td>512 GB</td>
</tr>
<tr>
<td>Hard Disk Technology</td>
<td>Solid State Drive</td>
</tr>
<tr>
<td>Graphics Coprocessor</td>
<td>Intel Integrated Graphics</td>
</tr>
<tr>
<td>Graphics Card Description</td>
<td>Integrated Graphics Card</td>
</tr>
<tr>
<td>Hardware Platform</td>
<td>Mac</td>
</tr>
<tr>
<td>Operating System</td>
<td>Mac OS</td>
</tr>
<tr>
<td>Average Battery Life (in hours)</td>
<td>9</td>
</tr>
</tbody>
</table>
			</div>
					<div class="woocommerce-Tabs-panel woocommerce-Tabs-panel--reviews panel entry-content wc-tab" id="tab-reviews" role="tabpanel" aria-labelledby="tab-title-reviews">
				<div id="reviews" class="electro-advanced-reviews">
	<div class="advanced-review row">
		<div class="col-xs-12 col-md-6">
			<h2 class="based-title">Based on 3 reviews</h2>
			<div class="avg-rating">
				<span class="avg-rating-number">5.0</span> overall			</div>
			<div class="rating-histogram">
								<div class="rating-bar">
					<div class="star-rating" title="Rated 5 out of 5">
						<span style="width:100%"></span>
					</div>
										<div class="rating-percentage-bar">
						<span style="width:100%" class="rating-percentage"></span>
					</div>
										<div class="rating-count">3</div>
									</div>
								<div class="rating-bar">
					<div class="star-rating" title="Rated 4 out of 5">
						<span style="width:80%"></span>
					</div>
										<div class="rating-percentage-bar">
						<span style="width:0%" class="rating-percentage"></span>
					</div>
										<div class="rating-count zero">0</div>
									</div>
								<div class="rating-bar">
					<div class="star-rating" title="Rated 3 out of 5">
						<span style="width:60%"></span>
					</div>
										<div class="rating-percentage-bar">
						<span style="width:0%" class="rating-percentage"></span>
					</div>
										<div class="rating-count zero">0</div>
									</div>
								<div class="rating-bar">
					<div class="star-rating" title="Rated 2 out of 5">
						<span style="width:40%"></span>
					</div>
										<div class="rating-percentage-bar">
						<span style="width:0%" class="rating-percentage"></span>
					</div>
										<div class="rating-count zero">0</div>
									</div>
								<div class="rating-bar">
					<div class="star-rating" title="Rated 1 out of 5">
						<span style="width:20%"></span>
					</div>
										<div class="rating-percentage-bar">
						<span style="width:0%" class="rating-percentage"></span>
					</div>
										<div class="rating-count zero">0</div>
									</div>
							</div>
		</div>
		<div class="col-xs-12 col-md-6">
			
			
			<div id="review_form_wrapper">
				<div id="review_form">
						<div id="respond" class="comment-respond">
		<h3 id="reply-title" class="comment-reply-title">Add a review <small><a rel="nofollow" id="cancel-comment-reply-link" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/#respond" style="display:none;">Cancel reply</a></small></h3>			<form action="https://demo2.chethemes.com/electro/wp-comments-post.php" method="post" id="commentform" class="comment-form" novalidate>
				<p class="comment-form-rating"><label for="rating">Your Rating</label><select name="rating" id="rating">
								<option value="">Rate&hellip;</option>
								<option value="5">Perfect</option>
								<option value="4">Good</option>
								<option value="3">Average</option>
								<option value="2">Not that bad</option>
								<option value="1">Very Poor</option>
							</select></p><p class="comment-form-comment"><label for="comment">Your Review</label><textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea></p><p class="comment-form-author"><label for="author">Name <span class="required">*</span></label> <input id="author" name="author" type="text" value="" size="30" aria-required="true" /></p>
<p class="comment-form-email"><label for="email">Email <span class="required">*</span></label> <input id="email" name="email" type="text" value="" size="30" aria-required="true" /></p>
<p class="form-submit"><input name="submit" type="submit" id="submit" class="submit" value="Add Review" /> <input type='hidden' name='comment_post_ID' value='2933' id='comment_post_ID' />
<input type='hidden' name='comment_parent' id='comment_parent' value='0' />
</p>			</form>
			</div><!-- #respond -->
					</div>
			</div>

				</div>
	</div>
	
	<div id="comments">
		
			<ol class="commentlist">
				<li class="comment even thread-even depth-1" id="li-comment-163">

	<div id="comment-163" class="comment_container">

		<img alt='' src='https://secure.gravatar.com/avatar/36996aa077c159521a9b35068ea5f5f9?s=60&#038;d=mm&#038;r=g' srcset='https://secure.gravatar.com/avatar/36996aa077c159521a9b35068ea5f5f9?s=120&#038;d=mm&#038;r=g 2x' class='avatar avatar-60 photo' height='60' width='60' />
		<div class="comment-text">

			<div class="star-rating"><span style="width:100%">Rated <strong class="rating">5</strong> out of 5</span></div>
	<p class="meta">
		<strong class="woocommerce-review__author">Peter Wargner</strong> <span class="woocommerce-review__dash">&ndash;</span> <time class="woocommerce-review__published-date" datetime="2016-04-05T10:31:58+00:00">April 5, 2016</time>
	</p>

<div class="description"><p>Fusce vitae nibh mi. Integer posuere, libero et ullamcorper facilisis, enim eros tincidunt orci, eget vestibulum sapien nisi ut leo. Cras finibus vel est ut mollis. Donec luctus condimentum ante et euismod.</p>
</div>
			<p class="meta">
				<strong>Peter Wargner</strong> &ndash; <time datetime="2016-04-05T10:31:58+00:00">April 5, 2016</time>
			</p>

		
		</div>
	</div>
</li><!-- #comment-## -->
<li class="comment odd alt thread-odd thread-alt depth-1" id="li-comment-164">

	<div id="comment-164" class="comment_container">

		<img alt='' src='https://secure.gravatar.com/avatar/d16c74631325fcffc7e63045a63bb661?s=60&#038;d=mm&#038;r=g' srcset='https://secure.gravatar.com/avatar/d16c74631325fcffc7e63045a63bb661?s=120&#038;d=mm&#038;r=g 2x' class='avatar avatar-60 photo' height='60' width='60' />
		<div class="comment-text">

			<div class="star-rating"><span style="width:100%">Rated <strong class="rating">5</strong> out of 5</span></div>
	<p class="meta">
		<strong class="woocommerce-review__author">Anna Kowalsky</strong> <span class="woocommerce-review__dash">&ndash;</span> <time class="woocommerce-review__published-date" datetime="2016-04-05T10:34:38+00:00">April 5, 2016</time>
	</p>

<div class="description"><p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse eget facilisis odio. Duis sodales augue eu tincidunt faucibus. Etiam justo ligula, placerat ac augue id, volutpat porta dui.</p>
</div>
			<p class="meta">
				<strong>Anna Kowalsky</strong> &ndash; <time datetime="2016-04-05T10:34:38+00:00">April 5, 2016</time>
			</p>

		
		</div>
	</div>
</li><!-- #comment-## -->
<li class="comment even thread-even depth-1" id="li-comment-165">

	<div id="comment-165" class="comment_container">

		<img alt='' src='https://secure.gravatar.com/avatar/38debe76927ff747511927a24098f7f1?s=60&#038;d=mm&#038;r=g' srcset='https://secure.gravatar.com/avatar/38debe76927ff747511927a24098f7f1?s=120&#038;d=mm&#038;r=g 2x' class='avatar avatar-60 photo' height='60' width='60' />
		<div class="comment-text">

			<div class="star-rating"><span style="width:100%">Rated <strong class="rating">5</strong> out of 5</span></div>
	<p class="meta">
		<strong class="woocommerce-review__author">John Doe</strong> <span class="woocommerce-review__dash">&ndash;</span> <time class="woocommerce-review__published-date" datetime="2016-04-05T10:35:03+00:00">April 5, 2016</time>
	</p>

<div class="description"><p>Sed id tincidunt sapien. Pellentesque cursus accumsan tellus, nec ultricies nulla sollicitudin eget. Donec feugiat orci vestibulum porttitor sagittis.</p>
</div>
			<p class="meta">
				<strong>John Doe</strong> &ndash; <time datetime="2016-04-05T10:35:03+00:00">April 5, 2016</time>
			</p>

		
		</div>
	</div>
</li><!-- #comment-## -->
			</ol>

			
			</div>

	<div class="clear"></div>
</div>			</div>
			</div>


	<section class="related products">

		<h2>Related products</h2>

		<ul class="products columns-4">
			
				<li class="post-2930 product type-product status-publish has-post-thumbnail product_cat-smartphones pa_brands-lg first instock shipping-taxable purchasable product-type-simple">
	<div class="product-outer"><div class="product-inner"><span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span><a href="https://demo2.chethemes.com/electro/product/notebook-purple-g952vx-t7008t/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><h2 class="woocommerce-loop-product__title">Notebook Purple G952VX-T7008T</h2><div class="product-thumbnail"><img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" /></div></a><div class="price-add-to-cart">
	<span class="price"><span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,780.00</span></span></span>
<div class="add-to-cart-wrap" data-toggle="tooltip" data-title="Add to cart"><a rel="nofollow" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add-to-cart=2930" data-quantity="1" data-product_id="2930" data-product_sku="5487FB8/17" class="button product_type_simple add_to_cart_button ajax_add_to_cart">Add to cart</a></div></div><!-- /.price-add-to-cart --><div class="hover-area"><div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2930">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2930" rel="nofollow" data-product-id="2930" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2930" class="add-to-compare-link" data-product_id="2930">Compare</a></div></div></div><!-- /.product-inner --></div><!-- /.product-outer --></li>

			
				<li class="post-2926 product type-product status-publish has-post-thumbnail product_cat-smartphones pa_brands-apple  instock featured shipping-taxable purchasable product-type-simple">
	<div class="product-outer"><div class="product-inner"><span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span><a href="https://demo2.chethemes.com/electro/product/smartphone-6s-64gb-lte/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><h2 class="woocommerce-loop-product__title">Smartphone 6S 64GB LTE</h2><div class="product-thumbnail"><img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" /></div></a><div class="price-add-to-cart">
	<span class="price"><span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,215.00</span></span></span>
<div class="add-to-cart-wrap" data-toggle="tooltip" data-title="Add to cart"><a rel="nofollow" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add-to-cart=2926" data-quantity="1" data-product_id="2926" data-product_sku="5487FB8/19" class="button product_type_simple add_to_cart_button ajax_add_to_cart">Add to cart</a></div></div><!-- /.price-add-to-cart --><div class="hover-area"><div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2926">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2926" rel="nofollow" data-product-id="2926" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2926" class="add-to-compare-link" data-product_id="2926">Compare</a></div></div></div><!-- /.product-inner --></div><!-- /.product-outer --></li>

			
				<li class="post-2927 product type-product status-publish has-post-thumbnail product_cat-smartphones pa_brands-microsoft  instock shipping-taxable purchasable product-type-simple">
	<div class="product-outer"><div class="product-inner"><span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span><a href="https://demo2.chethemes.com/electro/product/ultrabook-ux605ca-fc050t/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><h2 class="woocommerce-loop-product__title">Ultrabook UX605CA-FC050T</h2><div class="product-thumbnail"><img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone4-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" /></div></a><div class="price-add-to-cart">
	<span class="price"><span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,218.00</span></span></span>
<div class="add-to-cart-wrap" data-toggle="tooltip" data-title="Add to cart"><a rel="nofollow" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add-to-cart=2927" data-quantity="1" data-product_id="2927" data-product_sku="5487FB8/14" class="button product_type_simple add_to_cart_button ajax_add_to_cart">Add to cart</a></div></div><!-- /.price-add-to-cart --><div class="hover-area"><div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2927">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2927" rel="nofollow" data-product-id="2927" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2927" class="add-to-compare-link" data-product_id="2927">Compare</a></div></div></div><!-- /.product-inner --></div><!-- /.product-outer --></li>

			
				<li class="post-2643 product type-product status-publish has-post-thumbnail product_cat-smartphones pa_brands-lg last instock shipping-taxable purchasable product-type-simple">
	<div class="product-outer"><div class="product-inner"><span class="loop-product-categories"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/" rel="tag">Smartphones</a></span><a href="https://demo2.chethemes.com/electro/product/notebook-purple-g752vt-t7008t/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><h2 class="woocommerce-loop-product__title">Notebook Purple G752VT-T7008T</h2><div class="product-thumbnail"><img width="300" height="300" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-300x300.jpg" class="attachment-shop_catalog size-shop_catalog wp-post-image" alt="" /></div></a><div class="price-add-to-cart">
	<span class="price"><span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,780.00</span></span></span>
<div class="add-to-cart-wrap" data-toggle="tooltip" data-title="Add to cart"><a rel="nofollow" href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add-to-cart=2643" data-quantity="1" data-product_id="2643" data-product_sku="5487FB8/17" class="button product_type_simple add_to_cart_button ajax_add_to_cart">Add to cart</a></div></div><!-- /.price-add-to-cart --><div class="hover-area"><div class="action-buttons">
<div class="yith-wcwl-add-to-wishlist add-to-wishlist-2643">
		    <div class="yith-wcwl-add-button show" style="display:block">

	        
<a href="/electro/product/notebook-black-spire-v-nitro-vn7-591g/?add_to_wishlist=2643" rel="nofollow" data-product-id="2643" data-product-type="simple" class="add_to_wishlist" >
        Wishlist</a>
<img src="https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/images/wpspin_light.gif" class="ajax-loading" alt="loading" width="16" height="16" style="visibility:hidden" />
	    </div>

	    <div class="yith-wcwl-wishlistaddedbrowse hide" style="display:none;">
	        <span class="feedback">Product added!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div class="yith-wcwl-wishlistexistsbrowse hide" style="display:none">
	        <span class="feedback">The product is already in the wishlist!</span>
	        <a href="https://demo2.chethemes.com/electro/wishlist/" rel="nofollow">
	            Browse	        </a>
	    </div>

	    <div style="clear:both"></div>
	    <div class="yith-wcwl-wishlistaddresponse"></div>
	
</div>

<div class="clear"></div><a href="https://demo2.chethemes.com/electro?action=yith-woocompare-add-product&id=2643" class="add-to-compare-link" data-product_id="2643">Compare</a></div></div></div><!-- /.product-inner --></div><!-- /.product-outer --></li>

			
		</ul>

	</section>


</div><!-- #product-2933 -->


		
				</main><!-- #main -->
		</div><!-- #primary -->

		
<div id="sidebar" class="sidebar" role="complementary">
<aside id="electro_product_categories_widget-1" class="widget woocommerce widget_product_categories electro_widget_product_categories"><ul class="product-categories category-single"><li class="product_cat"><ul class="show-all-cat"><li class="product_cat"><span class="show-all-cat-dropdown">Show All Categories</span><ul>	<li class="cat-item cat-item-158"><a href="https://demo2.chethemes.com/electro/product-category/accessories/">Accessories</a> <span class="count">(11)</span>
</li>
	<li class="cat-item cat-item-75"><a href="https://demo2.chethemes.com/electro/product-category/gps-navi/">GPS &amp; Navi</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-76"><a href="https://demo2.chethemes.com/electro/product-category/home-entertainment/">Home Entertainment</a> <span class="count">(1)</span>
</li>
	<li class="cat-item cat-item-91"><a href="https://demo2.chethemes.com/electro/product-category/cameras-photography/">Cameras &amp; Photography</a> <span class="count">(5)</span>
</li>
	<li class="cat-item cat-item-96"><a href="https://demo2.chethemes.com/electro/product-category/car-electronic-gps/">Car Electronic &amp; GPS</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-100"><a href="https://demo2.chethemes.com/electro/product-category/computer-components/">Computer Components</a> <span class="count">(1)</span>
</li>
	<li class="cat-item cat-item-95"><a href="https://demo2.chethemes.com/electro/product-category/gadgets/">Gadgets</a> <span class="count">(3)</span>
</li>
	<li class="cat-item cat-item-81"><a href="https://demo2.chethemes.com/electro/product-category/laptops-computers/">Laptops &amp; Computers</a> <span class="count">(13)</span>
</li>
	<li class="cat-item cat-item-99"><a href="https://demo2.chethemes.com/electro/product-category/office-supplies/">Office Supplies</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-97"><a href="https://demo2.chethemes.com/electro/product-category/printers-ink/">Printers &amp; Ink</a> <span class="count">(1)</span>
</li>
	<li class="cat-item cat-item-92"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/">Smart Phones &amp; Tablets</a> <span class="count">(20)</span>
</li>
	<li class="cat-item cat-item-98"><a href="https://demo2.chethemes.com/electro/product-category/software/">Software</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-94"><a href="https://demo2.chethemes.com/electro/product-category/tv-audio/">TV &amp; Audio</a> <span class="count">(1)</span>
</li>
	<li class="cat-item cat-item-93"><a href="https://demo2.chethemes.com/electro/product-category/video-games-consoles/">Video Games &amp; Consoles</a> <span class="count">(3)</span>
</li>
</ul></li></ul><ul>	<li class="cat-item cat-item-92 current-cat-parent current-cat-ancestor"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/">Smart Phones &amp; Tablets</a> <span class="count">(20)</span>
<ul class='children'>
	<li class="cat-item cat-item-101"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/accessories-smart-phones-tablets/">Accessories</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-110"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/chargers-smart-phones-tablets/">Chargers</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-122"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/powerbanks/">Powerbanks</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-125 current-cat"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/">Smartphones</a> <span class="count">(16)</span>
	<ul class='children'>
	<li class="cat-item cat-item-133"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/cables/">Cables</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-134"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/chargers-smartphones/">Chargers</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-135"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/covers/">Covers</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-136"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/holders/">Holders</a> <span class="count">(0)</span>
</li>
	<li class="cat-item cat-item-137"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/smartphones/powerbanks-smartphones/">Powerbanks</a> <span class="count">(0)</span>
</li>
	</ul>
</li>
	<li class="cat-item cat-item-129"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/tablets/">Tablets</a> <span class="count">(4)</span>
</li>
</ul>
</li>
</ul></li></ul></aside><aside id="text-2" class="widget widget_text">			<div class="textwidget"><img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/02/shop-sidebar-ad-banner.jpg" alt="Banner"></div>
		</aside><aside id="woocommerce_products-2" class="widget woocommerce widget_products"><h3 class="widget-title">Latest Products</h3><ul class="product_list_widget">
<li>
	<a href="https://demo2.chethemes.com/electro/product/notebook-black-spire-v-nitro-vn7-591g/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Notebook Black Spire V Nitro  VN7-591G</span>
	</a>
		<span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,299.00</span></del></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/tablet-thin-elitebook-revolve-810-g6/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,300.00</span></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/notebook-widescreen-z51-70-40k6013upb/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone5-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone5-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone5-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone5-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone5-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Notebook Widescreen Z51-70  40K6013UPB</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,100.00</span></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/notebook-purple-g952vx-t7008t/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone8-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Notebook Purple G952VX-T7008T</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,780.00</span></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/laptop-yoga-21-80jh0035ge-w8-1-copy/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone2-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone2-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone2-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone2-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone2-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Laptop Yoga 21 80JH0035GE  W8.1 (Copy)</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>3,485.00</span></span></li>
</ul></aside></div><!-- /.sidebar-shop -->
	

		</div><!-- .col-full -->
	</div><!-- #content -->

	<section class="brands-carousel">
	<h2 class="sr-only">Brands Carousel</h2>
	<div class="container">
		<div id="owl-brands" class="owl-brands owl-carousel electro-owl-carousel owl-outer-nav" data-ride="owl-carousel" data-carousel-selector="self" data-carousel-options="{&quot;items&quot;:5,&quot;navRewind&quot;:true,&quot;autoplayHoverPause&quot;:true,&quot;nav&quot;:true,&quot;stagePadding&quot;:1,&quot;dots&quot;:false,&quot;rtl&quot;:false,&quot;navText&quot;:[&quot;&lt;i class=\&quot;fa fa-chevron-left\&quot;&gt;&lt;\/i&gt;&quot;,&quot;&lt;i class=\&quot;fa fa-chevron-right\&quot;&gt;&lt;\/i&gt;&quot;],&quot;touchDrag&quot;:false,&quot;responsive&quot;:{&quot;0&quot;:{&quot;items&quot;:1},&quot;480&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:2},&quot;992&quot;:{&quot;items&quot;:3},&quot;1200&quot;:{&quot;items&quot;:5}}}">
		
						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/acer/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Acer</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/themeforest.png" alt="Acer" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/apple/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Apple</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/graphicriver.png" alt="Apple" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/asus/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Asus</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/codecanyon.png" alt="Asus" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/dell/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Dell</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/audiojungle.png" alt="Dell" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/gionee/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Gionee</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/activeden.png" alt="Gionee" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/hp/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>HP</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/3docean.png" alt="HP" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/htc/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>HTC</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/themeforest.png" alt="HTC" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/ibm/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>IBM</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/graphicriver.png" alt="IBM" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/lenova/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Lenova</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/codecanyon.png" alt="Lenova" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/lg/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>LG</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/audiojungle.png" alt="LG" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/micromax/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Micromax</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/activeden.png" alt="Micromax" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
			<div class="item">
				<a href="https://demo2.chethemes.com/electro/brands/microsoft/">
				<figure>
					<figcaption class="text-overlay">
						<div class="info">
							<h4>Microsoft</h4>
						</div><!-- /.info -->
					</figcaption>
									<img src="https://demo2.chethemes.com/electro/wp-content/uploads/2016/03/3docean.png" alt="Microsoft" width="200" height="60" class="img-responsive desaturate">
				</figure>
				</a>
			</div><!-- /.item -->

						
		</div><!-- /.owl-carousel -->
	</div>
</section>
	<footer id="colophon" class="site-footer">
			
					<div class="footer-widgets">
				<div class="container">
					<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><aside id="woocommerce_products-4" class="widget clearfix woocommerce widget_products"><div class="body"><h4 class="widget-title">Featured Products</h4><ul class="product_list_widget">
<li>
	<a href="https://demo2.chethemes.com/electro/product/tablet-thin-elitebook-revolve-810-g6/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,300.00</span></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/smartphone-6s-128gb-lte/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone7-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone7-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone7-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone7-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone7-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Smartphone 6S 128GB LTE</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>780.00</span></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/smartphone-6s-64gb-lte/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Smartphone 6S 64GB LTE</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,215.00</span></span></li>
</ul></div></aside></div><div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><aside id="woocommerce_products-3" class="widget clearfix woocommerce widget_products"><div class="body"><h4 class="widget-title">Top Selling Products</h4><ul class="product_list_widget">
<li>
	<a href="https://demo2.chethemes.com/electro/product/game-console-controller-usb-3-0-cable/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GamePad-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GamePad-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GamePad-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GamePad-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GamePad-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Game Console Controller + USB 3.0 Cable</span>
	</a>
		<span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>79.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>99.00</span></del></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/wireless-audio-system-multiroom-360/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/WirelessSound-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/WirelessSound-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/WirelessSound-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/WirelessSound-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/WirelessSound-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Wireless Audio System Multiroom 360</span>
	</a>
		<span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,299.00</span></del></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/tablet-white-elitebook-revolve-810-g2/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/LaptopYoga-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/LaptopYoga-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/LaptopYoga-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/LaptopYoga-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/LaptopYoga-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet White EliteBook  Revolve 810 G2</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,300.00</span></span></li>
</ul></div></aside></div><div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><aside id="woocommerce_products-5" class="widget clearfix woocommerce widget_products"><div class="body"><h4 class="widget-title">On-sale Products</h4><ul class="product_list_widget">
<li>
	<a href="https://demo2.chethemes.com/electro/product/notebook-black-spire-v-nitro-vn7-591g/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/GoldPhone-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Notebook Black Spire V Nitro  VN7-591G</span>
	</a>
		<span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,299.00</span></del></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/tablet-red-elitebook-revolve-810-g2/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Ultrabooks-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Ultrabooks-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Ultrabooks-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Ultrabooks-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Ultrabooks-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet Red EliteBook  Revolve 810 G2</span>
	</a>
		<span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,299.00</span></del></span></li>

<li>
	<a href="https://demo2.chethemes.com/electro/product/widescreen-4k-suhd-tv/">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/TV-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/TV-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/TV-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/TV-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/TV-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Widescreen 4K SUHD TV</span>
	</a>
		<span class="electro-price"><ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>2,999.00</span></ins> <del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>3,299.00</span></del></span></li>
</ul></div></aside></div>					</div>
				</div>
			</div>
						<div class="footer-newsletter">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-7">

							<h5 class="newsletter-title">Sign up to Newsletter</h5>

							
							<span class="newsletter-marketing-text">...and receive <strong>$20 coupon for first shopping</strong></span>

							
						</div>
						<div class="col-xs-12 col-sm-5">

									<form>
			<div class="input-group">
				<input type="text" class="form-control" placeholder="Enter your email address">
				<span class="input-group-btn">
					<button class="btn btn-secondary" type="button">Sign Up</button>
				</span>
			</div>
		</form>
		
						</div>
					</div>
				</div>
			</div>
					
		<div class="footer-bottom-widgets">
			<div class="container">
								<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-7 col-md-push-5">
					<div class="columns"><aside id="nav_menu-1" class="widget clearfix widget_nav_menu"><div class="body"><h4 class="widget-title">Find It Fast</h4><div class="menu-footer-menu-1-container"><ul id="menu-footer-menu-1" class="menu"><li id="menu-item-3102" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3102"><a href="https://demo2.chethemes.com/electro/product-category/laptops-computers/">Laptops &amp; Computers</a></li>
<li id="menu-item-3103" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3103"><a href="https://demo2.chethemes.com/electro/product-category/cameras-photography/">Cameras &amp; Photography</a></li>
<li id="menu-item-3104" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat current-product-ancestor menu-item-3104"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/">Smart Phones &amp; Tablets</a></li>
<li id="menu-item-3105" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3105"><a href="https://demo2.chethemes.com/electro/product-category/video-games-consoles/">Video Games &amp; Consoles</a></li>
<li id="menu-item-3106" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3106"><a href="https://demo2.chethemes.com/electro/product-category/tv-audio/">TV &amp; Audio</a></li>
<li id="menu-item-3107" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3107"><a href="https://demo2.chethemes.com/electro/product-category/gadgets/">Gadgets</a></li>
<li id="menu-item-3108" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3108"><a href="https://demo2.chethemes.com/electro/product-category/car-electronic-gps/">Car Electronic &amp; GPS</a></li>
</ul></div></div></aside></div><div class="columns"><aside id="nav_menu-2" class="widget clearfix widget_nav_menu"><div class="body"><h4 class="widget-title"> </h4><div class="menu-footer-menu-2-container"><ul id="menu-footer-menu-2" class="menu"><li id="menu-item-3109" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3109"><a href="https://demo2.chethemes.com/electro/product-category/printers-ink/">Printers &amp; Ink</a></li>
<li id="menu-item-3110" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3110"><a href="https://demo2.chethemes.com/electro/product-category/software/">Software</a></li>
<li id="menu-item-3111" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3111"><a href="https://demo2.chethemes.com/electro/product-category/office-supplies/">Office Supplies</a></li>
<li id="menu-item-3112" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3112"><a href="https://demo2.chethemes.com/electro/product-category/computer-components/">Computer Components</a></li>
</ul></div></div></aside></div><div class="columns"><aside id="nav_menu-3" class="widget clearfix widget_nav_menu"><div class="body"><h4 class="widget-title">Customer Care</h4><div class="menu-footer-menu-3-container"><ul id="menu-footer-menu-3" class="menu"><li id="menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3166"><a href="https://demo2.chethemes.com/electro/my-account/">My Account</a></li>
<li id="menu-item-3167" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3167"><a href="https://demo2.chethemes.com/electro/track-your-order/">Track your Order</a></li>
<li id="menu-item-3169" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3169"><a href="https://demo2.chethemes.com/electro/contact-v1/">Customer Service</a></li>
<li id="menu-item-3170" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3170"><a href="https://demo2.chethemes.com/electro/contact-v2/">Returns/Exchange</a></li>
<li id="menu-item-3171" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3171"><a href="https://demo2.chethemes.com/electro/faq/">FAQs</a></li>
<li id="menu-item-3172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3172"><a href="https://demo2.chethemes.com/electro/terms-and-conditions/">Product Support</a></li>
</ul></div></div></aside></div>					</div>
					<div class="footer-contact col-xs-12 col-sm-12 col-md-5 col-md-pull-7">
									<div class="footer-logo">
				<svg version="1.1" x="0px" y="0px" width="156px"
					height="37px" viewBox="0 0 175.748 42.52" enable-background="new 0 0 175.748 42.52">
					<ellipse fill-rule="evenodd" clip-rule="evenodd" fill="#FDD700" cx="170.05" cy="36.341" rx="5.32" ry="5.367"/>
					<path fill-rule="evenodd" clip-rule="evenodd" fill="#333E48" d="M30.514,0.71c-0.034,0.003-0.066,0.008-0.056,0.056
					C30.263,0.995,29.876,1.181,29.79,1.5c-0.148,0.548,0,1.568,0,2.427v36.459c0.265,0.221,0.506,0.465,0.725,0.734h6.187
					c0.2-0.25,0.423-0.477,0.669-0.678V1.387C37.124,1.185,36.9,0.959,36.701,0.71H30.514z M117.517,12.731
					c-0.232-0.189-0.439-0.64-0.781-0.734c-0.754-0.209-2.039,0-3.121,0h-3.176V4.435c-0.232-0.189-0.439-0.639-0.781-0.733
					c-0.719-0.2-1.969,0-3.01,0h-3.01c-0.238,0.273-0.625,0.431-0.725,0.847c-0.203,0.852,0,2.399,0,3.725
					c0,1.393,0.045,2.748-0.055,3.725h-6.41c-0.184,0.237-0.629,0.434-0.725,0.791c-0.178,0.654,0,1.813,0,2.765v2.766
					c0.232,0.188,0.439,0.64,0.779,0.733c0.777,0.216,2.109,0,3.234,0c1.154,0,2.291-0.045,3.176,0.057v21.277
					c0.232,0.189,0.439,0.639,0.781,0.734c0.719,0.199,1.969,0,3.01,0h3.01c1.008-0.451,0.725-1.889,0.725-3.443
					c-0.002-6.164-0.047-12.867,0.055-18.625h6.299c0.182-0.236,0.627-0.434,0.725-0.79c0.176-0.653,0-1.813,0-2.765V12.731z
					 M135.851,18.262c0.201-0.746,0-2.029,0-3.104v-3.104c-0.287-0.245-0.434-0.637-0.781-0.733c-0.824-0.229-1.992-0.044-2.898,0
					c-2.158,0.104-4.506,0.675-5.74,1.411c-0.146-0.362-0.451-0.853-0.893-0.96c-0.693-0.169-1.859,0-2.842,0h-2.842
					c-0.258,0.319-0.625,0.42-0.725,0.79c-0.223,0.82,0,2.338,0,3.443c0,8.109-0.002,16.635,0,24.381
					c0.232,0.189,0.439,0.639,0.779,0.734c0.707,0.195,1.93,0,2.955,0h3.01c0.918-0.463,0.725-1.352,0.725-2.822V36.21
					c-0.002-3.902-0.242-9.117,0-12.473c0.297-4.142,3.836-4.877,8.527-4.686C135.312,18.816,135.757,18.606,135.851,18.262z
					 M14.796,11.376c-5.472,0.262-9.443,3.178-11.76,7.056c-2.435,4.075-2.789,10.62-0.501,15.126c2.043,4.023,5.91,7.115,10.701,7.9
					c6.051,0.992,10.992-1.219,14.324-3.838c-0.687-1.1-1.419-2.664-2.118-3.951c-0.398-0.734-0.652-1.486-1.616-1.467
					c-1.942,0.787-4.272,2.262-7.134,2.145c-3.791-0.154-6.659-1.842-7.524-4.91h19.452c0.146-2.793,0.22-5.338-0.279-7.563
					C26.961,15.728,22.503,11.008,14.796,11.376z M9,23.284c0.921-2.508,3.033-4.514,6.298-4.627c3.083-0.107,4.994,1.976,5.685,4.627
					C17.119,23.38,12.865,23.38,9,23.284z M52.418,11.376c-5.551,0.266-9.395,3.142-11.76,7.056
					c-2.476,4.097-2.829,10.493-0.557,15.069c1.997,4.021,5.895,7.156,10.646,7.957c6.068,1.023,11-1.227,14.379-3.781
					c-0.479-0.896-0.875-1.742-1.393-2.709c-0.312-0.582-1.024-2.234-1.561-2.539c-0.912-0.52-1.428,0.135-2.23,0.508
					c-0.564,0.262-1.223,0.523-1.672,0.676c-4.768,1.621-10.372,0.268-11.537-4.176h19.451c0.668-5.443-0.419-9.953-2.73-13.037
					C61.197,13.388,57.774,11.12,52.418,11.376z M46.622,23.343c0.708-2.553,3.161-4.578,6.242-4.686
					c3.08-0.107,5.08,1.953,5.686,4.686H46.622z M160.371,15.497c-2.455-2.453-6.143-4.291-10.869-4.064
					c-2.268,0.109-4.297,0.65-6.02,1.524c-1.719,0.873-3.092,1.957-4.234,3.217c-2.287,2.519-4.164,6.004-3.902,11.007
					c0.248,4.736,1.979,7.813,4.627,10.326c2.568,2.439,6.148,4.254,10.867,4.064c4.457-0.18,7.889-2.115,10.199-4.684
					c2.469-2.746,4.012-5.971,3.959-11.063C164.949,21.134,162.732,17.854,160.371,15.497z M149.558,33.952
					c-3.246-0.221-5.701-2.615-6.41-5.418c-0.174-0.689-0.26-1.25-0.4-2.166c-0.035-0.234,0.072-0.523-0.045-0.77
					c0.682-3.698,2.912-6.257,6.799-6.547c2.543-0.189,4.258,0.735,5.52,1.863c1.322,1.182,2.303,2.715,2.451,4.967
					C157.789,30.669,154.185,34.267,149.558,33.952z M88.812,29.55c-1.232,2.363-2.9,4.307-6.13,4.402
					c-4.729,0.141-8.038-3.16-8.025-7.563c0.004-1.412,0.324-2.65,0.947-3.726c1.197-2.061,3.507-3.688,6.633-3.612
					c3.222,0.079,4.966,1.708,6.632,3.668c1.328-1.059,2.529-1.948,3.9-2.99c0.416-0.315,1.076-0.688,1.227-1.072
					c0.404-1.031-0.365-1.502-0.891-2.088c-2.543-2.835-6.66-5.377-11.704-5.137c-6.02,0.288-10.218,3.697-12.484,7.846
					c-1.293,2.365-1.951,5.158-1.729,8.408c0.209,3.053,1.191,5.496,2.619,7.508c2.842,4.004,7.385,6.973,13.656,6.377
					c5.976-0.568,9.574-3.936,11.816-8.354c-0.141-0.271-0.221-0.604-0.336-0.902C92.929,31.364,90.843,30.485,88.812,29.55z"/>
				</svg>
			</div>
			
			<div class="footer-call-us">
				<div class="media">
					<span class="media-left call-us-icon media-middle"><i class="ec ec-support"></i></span>
					<div class="media-body">
						<span class="call-us-text">Got Questions ? Call us 24/7!</span>
						<span class="call-us-number">(800) 8001-8588, (0600) 874 548</span>
					</div>
				</div>
			</div>

		
			<div class="footer-address">
				<strong class="footer-address-title">Contact Info</strong>
				<address>17 Princess Road, London, Greater London NW1 8JR, UK</address>
			</div>

					<div class="footer-social-icons">
				<ul class="social-icons list-unstyled">
					<li><a class="fa fa-facebook" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-twitter" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-pinterest" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-linkedin" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-google-plus" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-tumblr" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-instagram" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-youtube" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-rss" href="https://demo2.chethemes.com/electro/feed/"></a></li>				</ul>
			</div>
								</div>
				</div>
							</div>
		</div>		
		<div class="copyright-bar">
			<div class="container">
				<div class="pull-left flip copyright">&copy; <a href="https://demo2.chethemes.com/electro/">Electro</a> - All Rights Reserved</div>
				<div class="pull-right flip payment">		<div class="footer-payment-logo">
			<ul class="cash-card card-inline">
												<li class="card-item"><img src="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/patment-icon.png" style="max-width: none" alt="" width="324" height="38"></li>
							</ul>
		</div><!-- /.payment-methods -->
		</div>
			</div>
		</div>
	</footer><!-- #colophon -->

					<div class="electro-handheld-footer-bar hidden-lg-up">
					<ul class="columns-5">
													<li class="my-account">
								<a href="https://demo2.chethemes.com/electro/my-account/">My Account</a>							</li>
													<li class="search">
								<a href="">Search</a>			<div class="site-search">
				<div class="widget woocommerce widget_product_search"><form role="search" method="get" class="woocommerce-product-search" action="https://demo2.chethemes.com/electro/">
	<label class="screen-reader-text" for="woocommerce-product-search-field-0">Search for:</label>
	<input type="search" id="woocommerce-product-search-field-0" class="search-field" placeholder="Search products&hellip;" value="" name="s" />
	<input type="submit" value="Search" />
	<input type="hidden" name="post_type" value="product" />
</form>
</div>			</div>
									</li>
													<li class="cart">
											<a class="footer-cart-contents" href="https://demo2.chethemes.com/electro/cart/" title="View your shopping cart">
				<span class="cart-items-count count">0</span>
			</a>
									</li>
													<li class="wishlist">
											<a href="https://demo2.chethemes.com/electro/wishlist/" class="has-icon"><i class="ec ec-favorites"></i><span class="count">0</span></a>							</li>
													<li class="compare">
											<a href="https://demo2.chethemes.com/electro/compare/" class="has-icon"><i class="ec ec-compare"></i><span class="count">1</span></a>							</li>
											</ul>
				</div>
				
</div><!-- #page -->

<script type="application/ld+json">{"@context":"https:\/\/schema.org\/","@graph":[{"@context":"https:\/\/schema.org\/","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":"1","item":{"name":"Home","@id":"https:\/\/demo2.chethemes.com\/electro"}},{"@type":"ListItem","position":"2","item":{"name":"Smart Phones &amp; Tablets","@id":"https:\/\/demo2.chethemes.com\/electro\/product-category\/smart-phones-tablets\/"}},{"@type":"ListItem","position":"3","item":{"name":"Smartphones","@id":"https:\/\/demo2.chethemes.com\/electro\/product-category\/smart-phones-tablets\/smartphones\/"}},{"@type":"ListItem","position":"4","item":{"name":"Notebook Black Spire V Nitro VN7-591G"}}]},{"@context":"https:\/\/schema.org\/","@type":"Product","@id":"https:\/\/demo2.chethemes.com\/electro\/product\/notebook-black-spire-v-nitro-vn7-591g\/","name":"Notebook Black Spire V Nitro VN7-591G","image":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/uploads\/2016\/03\/GoldPhone.jpg","description":"4.5 inch HD Screen Android 4.4 KitKat OS 1.4 GHz Quad Core\u2122 Processor 20 MP front Camera","sku":"5487FB8\/22","offers":[{"@type":"Offer","price":"1999.00","priceCurrency":"USD","availability":"https:\/\/schema.org\/InStock","url":"https:\/\/demo2.chethemes.com\/electro\/product\/notebook-black-spire-v-nitro-vn7-591g\/","seller":{"@type":"Organization","name":"Electro","url":"https:\/\/demo2.chethemes.com\/electro"}}],"aggregateRating":{"@type":"AggregateRating","ratingValue":"5.00","ratingCount":"3","reviewCount":"3"}},{"@context":"https:\/\/schema.org\/","@graph":[{"@type":"Review","@id":"https:\/\/demo2.chethemes.com\/electro\/product\/notebook-black-spire-v-nitro-vn7-591g\/#comment-163","datePublished":"2016-04-05T10:31:58+00:00","description":"Fusce vitae nibh mi. Integer posuere, libero et ullamcorper facilisis, enim eros tincidunt orci, eget vestibulum sapien nisi ut leo. Cras finibus vel est ut mollis. Donec luctus condimentum ante et euismod.","itemReviewed":{"@type":"Product","name":"Notebook Black Spire V Nitro VN7-591G"},"reviewRating":{"@type":"rating","ratingValue":"5"},"author":{"@type":"Person","name":"Peter Wargner"}},{"@type":"Review","@id":"https:\/\/demo2.chethemes.com\/electro\/product\/notebook-black-spire-v-nitro-vn7-591g\/#comment-164","datePublished":"2016-04-05T10:34:38+00:00","description":"Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse eget facilisis odio. Duis sodales augue eu tincidunt faucibus. Etiam justo ligula, placerat ac augue id, volutpat porta dui.","itemReviewed":{"@type":"Product","name":"Notebook Black Spire V Nitro VN7-591G"},"reviewRating":{"@type":"rating","ratingValue":"5"},"author":{"@type":"Person","name":"Anna Kowalsky"}},{"@type":"Review","@id":"https:\/\/demo2.chethemes.com\/electro\/product\/notebook-black-spire-v-nitro-vn7-591g\/#comment-165","datePublished":"2016-04-05T10:35:03+00:00","description":"Sed id tincidunt sapien. Pellentesque cursus accumsan tellus, nec ultricies nulla sollicitudin eget. Donec feugiat orci vestibulum porttitor sagittis.","itemReviewed":{"@type":"Product","name":"Notebook Black Spire V Nitro VN7-591G"},"reviewRating":{"@type":"rating","ratingValue":"5"},"author":{"@type":"Person","name":"John Doe"}}]}]}</script>
<!-- Root element of PhotoSwipe. Must have class pswp. -->
<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">

	<!-- Background of PhotoSwipe. It's a separate element as animating opacity is faster than rgba(). -->
	<div class="pswp__bg"></div>

	<!-- Slides wrapper with overflow:hidden. -->
	<div class="pswp__scroll-wrap">

		<!-- Container that holds slides.
		PhotoSwipe keeps only 3 of them in the DOM to save memory.
		Don't modify these 3 pswp__item elements, data is added later on. -->
		<div class="pswp__container">
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
			<div class="pswp__item"></div>
		</div>

		<!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
		<div class="pswp__ui pswp__ui--hidden">

			<div class="pswp__top-bar">

				<!--  Controls are self-explanatory. Order can be changed. -->

				<div class="pswp__counter"></div>

				<button class="pswp__button pswp__button--close" aria-label="Close (Esc)"></button>

				<button class="pswp__button pswp__button--share" aria-label="Share"></button>

				<button class="pswp__button pswp__button--fs" aria-label="Toggle fullscreen"></button>

				<button class="pswp__button pswp__button--zoom" aria-label="Zoom in/out"></button>

				<!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
				<!-- element will get class pswp__preloader--active when preloader is running -->
				<div class="pswp__preloader">
					<div class="pswp__preloader__icn">
						<div class="pswp__preloader__cut">
							<div class="pswp__preloader__donut"></div>
						</div>
					</div>
				</div>
			</div>

			<div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
				<div class="pswp__share-tooltip"></div>
			</div>

			<button class="pswp__button pswp__button--arrow--left" aria-label="Previous (arrow left)"></button>

			<button class="pswp__button pswp__button--arrow--right" aria-label="Next (arrow right)"></button>

			<div class="pswp__caption">
				<div class="pswp__caption__center"></div>
			</div>

		</div>

	</div>

</div>
<link rel='stylesheet' id='js_composer_front-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.2' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/demo2.chethemes.com\/electro\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.9.2'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.6.4' defer='defer'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.6.4' defer='defer'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/zoom/jquery.zoom.min.js?ver=1.7.15'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/lib/bower/flexslider/jquery.flexslider-min.js?ver=5.2'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe.min.js?ver=4.1.1'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/photoswipe/photoswipe-ui-default.min.js?ver=4.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_single_product_params = {"i18n_required_rating_text":"Please select a rating","review_rating_required":"yes","flexslider":{"rtl":false,"animation":"slide","smoothHeight":true,"directionNav":false,"controlNav":"thumbnails","slideshow":false,"animationSpeed":500,"animationLoop":false,"allowOneSlide":false},"zoom_enabled":"1","photoswipe_enabled":"1","photoswipe_options":{"shareEl":false,"closeOnScroll":false,"history":false,"hideAnimationDuration":0,"showAnimationDuration":0},"flexslider_enabled":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/single-product.min.js?ver=3.2.6'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","wc_ajax_url":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.2.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","wc_ajax_url":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments_26f7ae9219740b589c63169aef2071bb"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.2.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var yith_woocompare = {"ajaxurl":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%","actionadd":"yith-woocompare-add-product","actionremove":"yith-woocompare-remove-product","actionview":"yith-woocompare-view-table","actionreload":"yith-woocompare-reload-product","added_label":"Added","table_title":"Product Comparison","auto_open":"yes","loader":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/plugins\/yith-woocommerce-compare\/assets\/images\/loader.gif","button_text":"Compare","cookie_name":"yith_woocompare_list","close_label":"Close"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-compare/assets/js/woocompare.min.js?ver=2.2.3'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-compare/assets/js/jquery.colorbox-min.js?ver=1.4.21'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","is_user_logged_in":"","ajax_loader_url":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif","remove_from_wishlist_after_add_to_cart":"yes","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies are enabled on your browser.","added_to_cart_message":"<div class=\"woocommerce-message\">Product correctly added to cart<\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","move_to_another_wishlist_action":"move_to_another_wishlsit","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.js?ver=2.2.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/tether.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/bootstrap.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/jquery.waypoints.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/typeahead.bundle.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/handlebars.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/jquery.easing.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/scrollup.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/bootstrap-hover-dropdown.min.js?ver=1.4.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var electro_options = {"rtl":"0","ajax_url":"https:\/\/demo2.chethemes.com\/electro\/wp-admin\/admin-ajax.php","ajax_loader_url":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/themes\/electro\/assets\/images\/ajax-loader.gif","enable_sticky_header":"","enable_live_search":"1","live_search_limit":"10","live_search_template":"<a href=\"{{url}}\" class=\"media live-search-media\"><img src=\"{{image}}\" class=\"media-left media-object flip pull-left\" height=\"60\" width=\"60\"><div class=\"media-body\"><p>{{{value}}}<\/p><\/div><\/a>","live_search_empty_msg":"Unable to find any products that match the currenty query","deal_countdown_text":{"days_text":"Days","hours_text":"Hours","mins_text":"Mins","secs_text":"Secs"},"typeahead_options":{"hint":false,"highlight":true},"compare_page_url":"https:\/\/demo2.chethemes.com\/electro\/compare\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/electro.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-includes/js/comment-reply.min.js?ver=4.9.3'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/owl.carousel.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/pace.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.2'></script>

</body>
</html>