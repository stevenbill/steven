<div class="top-bar hidden-md-down">
			<div class="container">
			<ul id="menu-top-bar-left" class="nav nav-inline pull-left animate-dropdown flip"><li id="menu-item-3060" class="menu-item menu-item-type-custom menu-item-object-custom animate-dropdown menu-item-3060"><a title="Welcome to Worldwide Electronics Store" href="#">Welcome to Worldwide Electronics Store</a></li>
</ul><ul id="menu-top-bar-right" class="nav nav-inline pull-right animate-dropdown flip"><li id="menu-item-3061" class="menu-item menu-item-type-custom menu-item-object-custom animate-dropdown menu-item-3061"><a title="Store Locator" href="#"><i class="ec ec-map-pointer"></i>Store Locator</a></li>
<li id="menu-item-3162" class="menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3162"><a title="Track Your Order" href="track-your-order.php"><i class="ec ec-transport"></i>Track Your Order</a></li>
<li id="menu-item-3156" class="menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3156"><a title="Shop" href="shop.php"><i class="ec ec-shopping-bag"></i>Shop</a></li>
<li id="menu-item-3157" class="menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3157"><a title="My Account" href="my-account.php"><i class="ec ec-user"></i>My Account</a></li>
</ul>			</div>
		</div>