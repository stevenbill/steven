


	<footer id="colophon" class="site-footer">
			
					<div class="footer-widgets">
				<div class="container">
					<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><aside id="woocommerce_products-4" class="widget clearfix woocommerce widget_products"><div class="body"><h4 class="widget-title">Featured Products</h4><ul class="product_list_widget">

					<?php  for ($x=0 ; $x<=2 ; $x++) {?>
<li>
	<a href="subproduct.php">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,300.00</span></span>
</li>
					<?php } ?>

</ul></div></aside></div>
<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><aside id="woocommerce_products-3" class="widget clearfix woocommerce widget_products"><div class="body"><h4 class="widget-title">Top Selling Products</h4><ul class="product_list_widget">

		<?php  for ($x=0 ; $x<=2 ; $x++) {?>
<li>
	<a href="subproduct.php">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,300.00</span></span>
</li>
					<?php } ?>
					
	
</ul></div></aside></div>

<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12"><aside id="woocommerce_products-5" class="widget clearfix woocommerce widget_products"><div class="body"><h4 class="widget-title">On-sale Products</h4><ul class="product_list_widget">
	<?php  for ($x=0 ; $x<=2 ; $x++) {?>
<li>
	<a href="subproduct.php">
		<img width="180" height="180" src="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg" class="attachment-shop_thumbnail size-shop_thumbnail wp-post-image" alt="" srcset="//demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-180x180.jpg 180w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-150x150.jpg 150w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-300x300.jpg 300w, //demo2.chethemes.com/electro/wp-content/uploads/2016/03/Smartphone6-600x600.jpg 600w" sizes="(max-width: 180px) 100vw, 180px" />		<span class="product-title">Tablet Thin EliteBook  Revolve 810 G6</span>
	</a>
		<span class="electro-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">&#36;</span>1,300.00</span></span>
</li>
					<?php } ?>
</ul></div></aside></div>					</div>
				</div>
			</div>
						
						
						
						
						<div class="footer-newsletter">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 col-sm-7">

							<h5 class="newsletter-title">Sign up to Newsletter</h5>

							
							<span class="newsletter-marketing-text">...and receive <strong>$20 coupon for first shopping</strong></span>

							
						</div>
						<div class="col-xs-12 col-sm-5">

									<form>
			<div class="input-group">
				<input type="text" class="form-control" placeholder="Enter your email address">
				<span class="input-group-btn">
					<button class="btn btn-secondary" type="button">Sign Up</button>
				</span>
			</div>
		</form>
		
						</div>
					</div>
				</div>
			</div>
					
		<div class="footer-bottom-widgets">
			<div class="container">
								<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-7 col-md-push-5">
					<div class="columns"><aside id="nav_menu-1" class="widget clearfix widget_nav_menu"><div class="body"><h4 class="widget-title">Find It Fast</h4><div class="menu-footer-menu-1-container"><ul id="menu-footer-menu-1" class="menu"><li id="menu-item-3102" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3102"><a href="https://demo2.chethemes.com/electro/product-category/laptops-computers/">Laptops &amp; Computers</a></li>
<li id="menu-item-3103" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3103"><a href="https://demo2.chethemes.com/electro/product-category/cameras-photography/">Cameras &amp; Photography</a></li>
<li id="menu-item-3104" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3104"><a href="https://demo2.chethemes.com/electro/product-category/smart-phones-tablets/">Smart Phones &amp; Tablets</a></li>
<li id="menu-item-3105" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3105"><a href="https://demo2.chethemes.com/electro/product-category/video-games-consoles/">Video Games &amp; Consoles</a></li>
<li id="menu-item-3106" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3106"><a href="https://demo2.chethemes.com/electro/product-category/tv-audio/">TV &amp; Audio</a></li>
<li id="menu-item-3107" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3107"><a href="https://demo2.chethemes.com/electro/product-category/gadgets/">Gadgets</a></li>
<li id="menu-item-3108" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3108"><a href="https://demo2.chethemes.com/electro/product-category/car-electronic-gps/">Car Electronic &amp; GPS</a></li>
</ul></div></div></aside></div><div class="columns"><aside id="nav_menu-2" class="widget clearfix widget_nav_menu"><div class="body"><h4 class="widget-title"> </h4><div class="menu-footer-menu-2-container"><ul id="menu-footer-menu-2" class="menu"><li id="menu-item-3109" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3109"><a href="https://demo2.chethemes.com/electro/product-category/printers-ink/">Printers &amp; Ink</a></li>
<li id="menu-item-3110" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3110"><a href="https://demo2.chethemes.com/electro/product-category/software/">Software</a></li>
<li id="menu-item-3111" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3111"><a href="https://demo2.chethemes.com/electro/product-category/office-supplies/">Office Supplies</a></li>
<li id="menu-item-3112" class="menu-item menu-item-type-taxonomy menu-item-object-product_cat menu-item-3112"><a href="https://demo2.chethemes.com/electro/product-category/computer-components/">Computer Components</a></li>
</ul></div></div></aside></div><div class="columns"><aside id="nav_menu-3" class="widget clearfix widget_nav_menu"><div class="body"><h4 class="widget-title">Customer Care</h4><div class="menu-footer-menu-3-container"><ul id="menu-footer-menu-3" class="menu"><li id="menu-item-3166" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3166"><a href="my-account.php">My Account</a></li>
<li id="menu-item-3167" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3167"><a href="track-your-order.php">Track your Order</a></li>
<li id="menu-item-3169" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3169"><a href="https://demo2.chethemes.com/electro/contact-v1/">Customer Service</a></li>
<li id="menu-item-3170" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3170"><a href="https://demo2.chethemes.com/electro/contact-v2/">Returns/Exchange</a></li>
<li id="menu-item-3171" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3171"><a href="https://demo2.chethemes.com/electro/faq/">FAQs</a></li>
<li id="menu-item-3172" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3172"><a href="https://demo2.chethemes.com/electro/terms-and-conditions/">Product Support</a></li>
</ul></div></div></aside></div>					</div>
					<div class="footer-contact col-xs-12 col-sm-12 col-md-5 col-md-pull-7">
									<div class="footer-logo">
				<svg version="1.1" x="0px" y="0px" width="156px"
					height="37px" viewBox="0 0 175.748 42.52" enable-background="new 0 0 175.748 42.52">
					<ellipse fill-rule="evenodd" clip-rule="evenodd" fill="#FDD700" cx="170.05" cy="36.341" rx="5.32" ry="5.367"/>
					<path fill-rule="evenodd" clip-rule="evenodd" fill="#333E48" d="M30.514,0.71c-0.034,0.003-0.066,0.008-0.056,0.056
					C30.263,0.995,29.876,1.181,29.79,1.5c-0.148,0.548,0,1.568,0,2.427v36.459c0.265,0.221,0.506,0.465,0.725,0.734h6.187
					c0.2-0.25,0.423-0.477,0.669-0.678V1.387C37.124,1.185,36.9,0.959,36.701,0.71H30.514z M117.517,12.731
					c-0.232-0.189-0.439-0.64-0.781-0.734c-0.754-0.209-2.039,0-3.121,0h-3.176V4.435c-0.232-0.189-0.439-0.639-0.781-0.733
					c-0.719-0.2-1.969,0-3.01,0h-3.01c-0.238,0.273-0.625,0.431-0.725,0.847c-0.203,0.852,0,2.399,0,3.725
					c0,1.393,0.045,2.748-0.055,3.725h-6.41c-0.184,0.237-0.629,0.434-0.725,0.791c-0.178,0.654,0,1.813,0,2.765v2.766
					c0.232,0.188,0.439,0.64,0.779,0.733c0.777,0.216,2.109,0,3.234,0c1.154,0,2.291-0.045,3.176,0.057v21.277
					c0.232,0.189,0.439,0.639,0.781,0.734c0.719,0.199,1.969,0,3.01,0h3.01c1.008-0.451,0.725-1.889,0.725-3.443
					c-0.002-6.164-0.047-12.867,0.055-18.625h6.299c0.182-0.236,0.627-0.434,0.725-0.79c0.176-0.653,0-1.813,0-2.765V12.731z
					 M135.851,18.262c0.201-0.746,0-2.029,0-3.104v-3.104c-0.287-0.245-0.434-0.637-0.781-0.733c-0.824-0.229-1.992-0.044-2.898,0
					c-2.158,0.104-4.506,0.675-5.74,1.411c-0.146-0.362-0.451-0.853-0.893-0.96c-0.693-0.169-1.859,0-2.842,0h-2.842
					c-0.258,0.319-0.625,0.42-0.725,0.79c-0.223,0.82,0,2.338,0,3.443c0,8.109-0.002,16.635,0,24.381
					c0.232,0.189,0.439,0.639,0.779,0.734c0.707,0.195,1.93,0,2.955,0h3.01c0.918-0.463,0.725-1.352,0.725-2.822V36.21
					c-0.002-3.902-0.242-9.117,0-12.473c0.297-4.142,3.836-4.877,8.527-4.686C135.312,18.816,135.757,18.606,135.851,18.262z
					 M14.796,11.376c-5.472,0.262-9.443,3.178-11.76,7.056c-2.435,4.075-2.789,10.62-0.501,15.126c2.043,4.023,5.91,7.115,10.701,7.9
					c6.051,0.992,10.992-1.219,14.324-3.838c-0.687-1.1-1.419-2.664-2.118-3.951c-0.398-0.734-0.652-1.486-1.616-1.467
					c-1.942,0.787-4.272,2.262-7.134,2.145c-3.791-0.154-6.659-1.842-7.524-4.91h19.452c0.146-2.793,0.22-5.338-0.279-7.563
					C26.961,15.728,22.503,11.008,14.796,11.376z M9,23.284c0.921-2.508,3.033-4.514,6.298-4.627c3.083-0.107,4.994,1.976,5.685,4.627
					C17.119,23.38,12.865,23.38,9,23.284z M52.418,11.376c-5.551,0.266-9.395,3.142-11.76,7.056
					c-2.476,4.097-2.829,10.493-0.557,15.069c1.997,4.021,5.895,7.156,10.646,7.957c6.068,1.023,11-1.227,14.379-3.781
					c-0.479-0.896-0.875-1.742-1.393-2.709c-0.312-0.582-1.024-2.234-1.561-2.539c-0.912-0.52-1.428,0.135-2.23,0.508
					c-0.564,0.262-1.223,0.523-1.672,0.676c-4.768,1.621-10.372,0.268-11.537-4.176h19.451c0.668-5.443-0.419-9.953-2.73-13.037
					C61.197,13.388,57.774,11.12,52.418,11.376z M46.622,23.343c0.708-2.553,3.161-4.578,6.242-4.686
					c3.08-0.107,5.08,1.953,5.686,4.686H46.622z M160.371,15.497c-2.455-2.453-6.143-4.291-10.869-4.064
					c-2.268,0.109-4.297,0.65-6.02,1.524c-1.719,0.873-3.092,1.957-4.234,3.217c-2.287,2.519-4.164,6.004-3.902,11.007
					c0.248,4.736,1.979,7.813,4.627,10.326c2.568,2.439,6.148,4.254,10.867,4.064c4.457-0.18,7.889-2.115,10.199-4.684
					c2.469-2.746,4.012-5.971,3.959-11.063C164.949,21.134,162.732,17.854,160.371,15.497z M149.558,33.952
					c-3.246-0.221-5.701-2.615-6.41-5.418c-0.174-0.689-0.26-1.25-0.4-2.166c-0.035-0.234,0.072-0.523-0.045-0.77
					c0.682-3.698,2.912-6.257,6.799-6.547c2.543-0.189,4.258,0.735,5.52,1.863c1.322,1.182,2.303,2.715,2.451,4.967
					C157.789,30.669,154.185,34.267,149.558,33.952z M88.812,29.55c-1.232,2.363-2.9,4.307-6.13,4.402
					c-4.729,0.141-8.038-3.16-8.025-7.563c0.004-1.412,0.324-2.65,0.947-3.726c1.197-2.061,3.507-3.688,6.633-3.612
					c3.222,0.079,4.966,1.708,6.632,3.668c1.328-1.059,2.529-1.948,3.9-2.99c0.416-0.315,1.076-0.688,1.227-1.072
					c0.404-1.031-0.365-1.502-0.891-2.088c-2.543-2.835-6.66-5.377-11.704-5.137c-6.02,0.288-10.218,3.697-12.484,7.846
					c-1.293,2.365-1.951,5.158-1.729,8.408c0.209,3.053,1.191,5.496,2.619,7.508c2.842,4.004,7.385,6.973,13.656,6.377
					c5.976-0.568,9.574-3.936,11.816-8.354c-0.141-0.271-0.221-0.604-0.336-0.902C92.929,31.364,90.843,30.485,88.812,29.55z"/>
				</svg>
			</div>
			
			<div class="footer-call-us">
				<div class="media">
					<span class="media-left call-us-icon media-middle"><i class="ec ec-support"></i></span>
					<div class="media-body">
						<span class="call-us-text">Got Questions ? Call us 24/7!</span>
						<span class="call-us-number">(800) 8001-8588, (0600) 874 548</span>
					</div>
				</div>
			</div>

		
			<div class="footer-address">
				<strong class="footer-address-title">Contact Info</strong>
				<address>17 Princess Road, London, Greater London NW1 8JR, UK</address>
			</div>

					<div class="footer-social-icons">
				<ul class="social-icons list-unstyled">
					<li><a class="fa fa-facebook" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-twitter" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-pinterest" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-linkedin" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-google-plus" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-tumblr" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-instagram" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-youtube" href="http://themeforest.net/user/shaikrilwan/portfolio"></a></li><li><a class="fa fa-rss" href="https://demo2.chethemes.com/electro/feed/"></a></li>				</ul>
			</div>
								</div>
				</div>
							</div>
		</div>		
		<div class="copyright-bar">
			<div class="container">
				<div class="pull-left flip copyright">&copy; <a href="https://demo2.chethemes.com/electro/">Electro</a> - All Rights Reserved</div>
				<div class="pull-right flip payment">		<div class="footer-payment-logo">
			<ul class="cash-card card-inline">
												<li class="card-item"><img src="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/patment-icon.png" style="max-width: none" alt="" width="324" height="38"></li>
							</ul>
		</div><!-- /.payment-methods -->
		</div>
			</div>
		</div>
	</footer><!-- #colophon -->

					<div class="electro-handheld-footer-bar hidden-lg-up">
					<ul class="columns-5">
													<li class="my-account">
								<a href="my-account.php">My Account</a>							</li>
													<li class="search">
								<a href="">Search</a>			<div class="site-search">
				<div class="widget woocommerce widget_product_search"><form role="search" method="get" class="woocommerce-product-search" action="https://demo2.chethemes.com/electro/">
	<label class="screen-reader-text" for="woocommerce-product-search-field-0">Search for:</label>
	<input type="search" id="woocommerce-product-search-field-0" class="search-field" placeholder="Search products&hellip;" value="" name="s" />
	<input type="submit" value="Search" />
	<input type="hidden" name="post_type" value="product" />
</form>
</div>			</div>
									</li>
													<li class="cart">
											<a class="footer-cart-contents" href="https://demo2.chethemes.com/electro/cart/" title="View your shopping cart">
				<span class="cart-items-count count">0</span>
			</a>
									</li>
													<li class="wishlist">
											<a href="https://demo2.chethemes.com/electro/wishlist/" class="has-icon"><i class="ec ec-favorites"></i><span class="count">0</span></a>							</li>
													<li class="compare">
											<a href="https://demo2.chethemes.com/electro/compare/" class="has-icon"><i class="ec ec-compare"></i><span class="count">0</span></a>							</li>
											</ul>
				</div>
				
</div><!-- #page -->

			<script type="text/javascript">
				function revslider_showDoubleJqueryError(sliderID) {
					var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
					errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
					errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
					errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
					errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
						jQuery(sliderID).show().php(errorMessage);
				}
			</script>
			<link rel='stylesheet' id='js_composer_front-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=5.2' type='text/css' media='all' />
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/demo2.chethemes.com\/electro\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Please verify that you are not a robot."}},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.9.2'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.4.6.4' defer='defer'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.4.6.4' defer='defer'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","wc_ajax_url":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.2.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","wc_ajax_url":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%","fragment_name":"wc_fragments_26f7ae9219740b589c63169aef2071bb"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.2.6'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var yith_woocompare = {"ajaxurl":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%","actionadd":"yith-woocompare-add-product","actionremove":"yith-woocompare-remove-product","actionview":"yith-woocompare-view-table","actionreload":"yith-woocompare-reload-product","added_label":"Added","table_title":"Product Comparison","auto_open":"yes","loader":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/plugins\/yith-woocommerce-compare\/assets\/images\/loader.gif","button_text":"Compare","cookie_name":"yith_woocompare_list","close_label":"Close"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-compare/assets/js/woocompare.min.js?ver=2.2.3'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-compare/assets/js/jquery.colorbox-min.js?ver=1.4.21'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","is_user_logged_in":"","ajax_loader_url":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif","remove_from_wishlist_after_add_to_cart":"yes","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies are enabled on your browser.","added_to_cart_message":"<div class=\"woocommerce-message\">Product correctly added to cart<\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","move_to_another_wishlist_action":"move_to_another_wishlsit","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.js?ver=2.2.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/tether.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/bootstrap.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/jquery.waypoints.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/typeahead.bundle.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/handlebars.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/jquery.easing.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/scrollup.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/bootstrap-hover-dropdown.min.js?ver=1.4.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var electro_options = {"rtl":"0","ajax_url":"https:\/\/demo2.chethemes.com\/electro\/wp-admin\/admin-ajax.php","ajax_loader_url":"https:\/\/demo2.chethemes.com\/electro\/wp-content\/themes\/electro\/assets\/images\/ajax-loader.gif","enable_sticky_header":"","enable_live_search":"1","live_search_limit":"10","live_search_template":"<a href=\"{{url}}\" class=\"media live-search-media\"><img src=\"{{image}}\" class=\"media-left media-object flip pull-left\" height=\"60\" width=\"60\"><div class=\"media-body\"><p>{{{value}}}<\/p><\/div><\/a>","live_search_empty_msg":"Unable to find any products that match the currenty query","deal_countdown_text":{"days_text":"Days","hours_text":"Hours","mins_text":"Mins","secs_text":"Secs"},"typeahead_options":{"hint":false,"highlight":true},"compare_page_url":"https:\/\/demo2.chethemes.com\/electro\/compare\/"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/electro.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/owl.carousel.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/js/pace.min.js?ver=1.4.0'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.2'></script>
<script>var phpDiv = document.getElementById("rs-plugin-settings-inline-css"); var phpDivCss=".tp-caption.home-v1-hero-1,.home-v1-hero-1{color:rgba(51,62,72,1.00);font-size:66px;line-height:52px;font-weight:300;font-style:normal;font-family:Open Sans;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-width:0px;border-radius:0 0 0 0px}.tp-caption.home-v1-display-2,.home-v1-display-2{color:rgba(51,62,72,1.00);font-size:59px;line-height:52px;font-weight:300;font-style:normal;font-family:Open Sans;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-width:0px;border-radius:0 0 0 0px}.tp-caption.action-btn,.action-btn{color:rgba(51,62,72,1.00);font-size:18px;line-height:17px;font-weight:300;font-style:normal;font-family:Open Sans;text-decoration:none;background-color:rgba(254,215,0,1.00);border-color:rgba(0,0,0,1.00);border-style:solid;border-width:0px;border-radius:10px 10px 10px 10px}.tp-caption.action-btn:hover,.action-btn:hover{color:rgba(51,62,72,1.00);text-decoration:none;background-color:rgba(239,202,0,1.00);border-color:rgba(0,0,0,1.00);border-style:solid;border-width:0px;border-radius:10px 10px 10px 10px;cursor:pointer}";
				if(phpDiv) {
					phpDiv.innerphp = phpDiv.innerphp + phpDivCss;
				}else{
					var phpDiv = document.createElement("div");
					phpDiv.innerphp = "<style>" + phpDivCss + "</style>";
					document.getElementsByTagName("head")[0].appendChild(phpDiv.childNodes[0]);
				}
			</script>
		<script type="text/javascript">
setREVStartSize({c: jQuery('#rev_slider_1_1'), responsiveLevels: [1240,1024,778,480], gridwidth: [1170,1170,778,680], gridheight: [485,490,324,320], sliderLayout: 'fullwidth', minHeight:'360'});
			
var revapi1,
	tpj=jQuery;
			
tpj(document).ready(function() {
	if(tpj("#rev_slider_1_1").revolution == undefined){
		revslider_showDoubleJqueryError("#rev_slider_1_1");
	}else{
		revapi1 = tpj("#rev_slider_1_1").show().revolution({
			sliderType:"standard",
			jsFileLocation:"//demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/js/",
			sliderLayout:"fullwidth",
			dottedOverlay:"none",
			delay:9000,
			navigation: {
				keyboardNavigation:"off",
				keyboard_direction: "horizontal",
				mouseScrollNavigation:"off",
 							mouseScrollReverse:"default",
				onHoverStop:"off",
				bullets: {
					enable:true,
					hide_onmobile:false,
					style:"custom",
					hide_onleave:false,
					direction:"horizontal",
					h_align:"center",
					v_align:"bottom",
					h_offset:0,
					v_offset:60,
					space:5,
					tmp:''
				}
			},
			responsiveLevels:[1240,1024,778,480],
			visibilityLevels:[1240,1024,778,480],
			gridwidth:[1170,1170,778,680],
			gridheight:[485,490,324,320],
			lazyType:"smart",
			minHeight:"360",
			shadow:0,
			spinner:"spinner0",
			stopLoop:"off",
			stopAfterLoops:-1,
			stopAtSlide:-1,
			shuffle:"off",
			autoHeight:"off",
			disableProgressBar:"on",
			hideThumbsOnMobile:"off",
			hideSliderAtLimit:0,
			hideCaptionAtLimit:0,
			hideAllCaptionAtLilmit:0,
			debugMode:false,
			fallbacks: {
				simplifyAll:"off",
				nextSlideOnWindowFocus:"off",
				disableFocusListener:false,
			}
		});
	}
	
});	/*ready*/
</script>
		
</body>
</php>