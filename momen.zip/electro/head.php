<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="https://demo2.chethemes.com/electro/xmlrpc.php">

<style>
@font-face {
 
         url('font/fontawesome-webfont.woff2') format('woff'),
		 url('font/font-electro.woff') format('woff'),
		 url('font/fontawesome-webfont.ttf') format('truetype'),
		 url('font/font-electro.ttf') format('truetype'),
		 }
</style>
				<!--<script type="text/javascript">document.documentElement.className = document.documentElement.className + ' yes-js js_active js'</script> -->
			<title>Electro &#8211; Electronics WooCommerce Theme</title>
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Electro &raquo; Feed" href="https://demo2.chethemes.com/electro/feed/" />
<link rel="alternate" type="application/rss+xml" title="Electro &raquo; Comments Feed" href="https://demo2.chethemes.com/electro/comments/feed/" />
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.9.2' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.6.4' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='jquery-colorbox-css'  href='https://demo2.chethemes.com/electro/wp-content/plugins/yith-woocommerce-compare/assets/css/colorbox.css?ver=4.9.3' type='text/css' media='all' />
<link rel='stylesheet' id='electro-fonts-css'  href='font1.css' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/bootstrap.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='fontawesome-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/font-awesome.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='animate-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/animate.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-electro-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/font-electro.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-style-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/style.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-child-style-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro-child/style.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-color-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/colors/yellow.min.css?ver=1.4.0' type='text/css' media='all' />
<link rel='stylesheet' id='electro-demo-color-css'  href='https://demo2.chethemes.com/electro/wp-content/themes/electro/assets/css/colors/blue.min.css?ver=4.9.3' type='text/css' media='all' />
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/electro\/wp-admin\/admin-ajax.php","wc_ajax_url":"https:\/\/demo2.chethemes.com\/electro\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/demo2.chethemes.com\/electro\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.2.6'></script>
<script type='text/javascript' src='https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=5.2'></script>
<link rel='https://api.w.org/' href='https://demo2.chethemes.com/electro/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://demo2.chethemes.com/electro/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://demo2.chethemes.com/electro/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.3" />
<meta name="generator" content="WooCommerce 3.2.6" />
<link rel="canonical" href="https://demo2.chethemes.com/electro/" />
<link rel='shortlink' href='https://demo2.chethemes.com/electro/' />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<meta name="generator" content="Powered by Visual Composer - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://demo2.chethemes.com/electro/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]--><meta name="generator" content="Powered by Slider Revolution 5.4.6.4 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-32x32.png" sizes="32x32" />
<link rel="icon" href="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-180x180.png" />
<meta name="msapplication-TileImage" content="https://demo2.chethemes.com/electro/wp-content/uploads/2017/02/cropped-fav-icon-lg-270x270.png" />
<script type="text/javascript">function setREVStartSize(e){
				try{ var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;					
					if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
				}catch(d){console.log("Failure at Presize of Slider:"+d)}
			};</script>
<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript>