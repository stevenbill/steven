<div class="collapse navbar-toggleable-xs" id="default-header">
				<ul id="menu-main-menu" class="nav nav-inline yamm">
					<li id="menu-item-3158" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children animate-dropdown menu-item-3158 dropdown">
						<a title="Home" href="index.php">Home</a>
					</li>
					<li id="menu-item-3181" class="menu-item menu-item-type-post_type menu-item-object-page animate-dropdown menu-item-3181">
						<a title="About Us" href="about.php">About Us</a></li>
					<li id="menu-item-3159" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children animate-dropdown menu-item-3159 dropdown">
						<a title="Blog" href="blog1.php" >Blog</a>
					</li>
					
						<li id="menu-item-3063" class="menu-item menu-item-type-custom menu-item-object-custom animate-dropdown menu-item-3063"><a title="Features" href="#">Features</a></li>
						<li id="menu-item-3064" class="menu-item menu-item-type-custom menu-item-object-custom animate-dropdown menu-item-3064">
							<a title="Contact Us" href="contact.php">Contact Us</a></li>
						</ul>			
					</div>